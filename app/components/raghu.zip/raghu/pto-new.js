/*
 * 
 * Copyright (c) 2016 by Cisco Systems, Inc.
 * All rights reserved.
 * 
 */

 
var serviceBasePath = '/mypto/mobile';  

var selectedTap = $(".job-footer");
var isFormValid = false;

var INTERNAL_SERVER_ERROR = 'Sorry, something went wrong while processing your request. The support team has been notified. Please try your request after sometime.';
  
function getQueryStrings() { 
  
  var assoc  = {};
  var decode = function (s) { return decodeURIComponent(s.replace(/\+/g, " ")); };
  var queryString = location.search.substring(1); 
  var keyValues = queryString.split('&'); 

  for(var i in keyValues) { 
    var key = keyValues[i].split('=');
    if (key.length > 1) {
      assoc[decode(key[0])] = decode(key[1]);
    }
  } 

  return assoc; 

}

function isMobile(){
    return (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) ? true : false;
};

var isPTOformValid = false;

function weeksInMonth() {
    var millisecondsInThisMonth = this.clone().endOfMonth().epoch() - this.clone().firstDayInCalendarMonth().epoch();
    return Math.ceil(millisecondsInThisMonth / MILLISECONDS_IN_WEEK);
}

function generateHashCode(s){
  return s.split("").reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0);              
}

function settotalHour(th) {
    totalHour = parseFloat(th);
}

function gettotalHour() {
    return parseFloat(totalHour);
}

function getCurHourType() {
    return currentHourTypeLen;
}

function setCurHourType(type) {
    currentHourTypeLen = type;
}

function getGlobalI() 
{
    return i;
}

function handleContiguosPTO(date){

    var isWeekend = function (date) {
        
        var weekend;

        if (country == 'IL' || country == 'AE') {
            weekend = date.getDay() === 5 || date.getDay() === 6;
            return [weekend, weekend ? 'NONWORKING_day' : ''];

        } 

        if (country == 'SA') {
            // For Saudi, Thursday and Friday is the weekend
            weekend = date.getDay() === 5 || date.getDay() === 6;
            return [weekend, weekend ? 'NONWORKING_day' : ''];

        } 

        weekend = date.getDay() === 0 || date.getDay() === 6;
        return [weekend, weekend ? 'NONWORKING_day' : ''];

    };

    var isWeekday = function (date) {
        return !isWeekend(date)[0];
    };

    var dateExistsAsPTO = function (date) {

        var hist = fixPTOHistoryJSON();
        var ddDate = moment(date).isValid() ? moment(date).toDate() : moment(date,'MM-DD-YYYY').toDate();
        var formattedDate =  pto_FormatDate( 'YYYY-MM-DD' ,ddDate);
        return _.where(hist,{'absenceDate':formattedDate}).length > 0 ? true : false;   
       
    };

    var __getContiguousPTO = function (date) {
        // from selected date, go backwards until we reach a non-PTO, non-weekend, non-holiday, then do the same forwards
        // date: Date object
        // returns array of dates strings YYYY-MM-DD, eg 2010-05-09
        var contigDates = [];
        var contig = false;
        var beforeDates = [];
        // get prior contiguous days
        var before = 0;
        var contigCount = 0;

        var dateYYYYMMDD =  null;        
              
        dateYYYYMMDD = moment(date,'MM-DD-YYYY').format('YYYY-MM-DD'); 

        var dayCounter = 0;
        var ptoItemsBeforeSelectedDates = [];

        while(true){
            
            var prevDate = moment(dateYYYYMMDD).subtract( ++dayCounter , 'days').toDate();

             // if its a weekend or weekday then stop going
            if( !isWeekday(prevDate) ){
                break;
            } 

            if( isWeekday(prevDate) && !dateExistsAsPTO(prevDate)){
                break;
            }
             
           
            if( dateExistsAsPTO(prevDate) ){
               ptoItemsBeforeSelectedDates.push(prevDate)  
            }

        }
        
        dayCounter = 0;
        var ptoItemsAfterSelectedDates = [];
        while(true){
            
            var nextDate = moment(dateYYYYMMDD).add( ++dayCounter , 'days').toDate();

             // if its a weekend or weekday then stop going
            if( !isWeekday(nextDate) ){
                break;
            } 

            if( isWeekday(nextDate) && !dateExistsAsPTO(nextDate)){
                break;
            }
             
           
            if( dateExistsAsPTO(nextDate) ){
               ptoItemsAfterSelectedDates.push(nextDate)  
            }

        }

        var contiguousPTOCollection = _.uniq(_.union(ptoItemsBeforeSelectedDates, ptoItemsAfterSelectedDates), false );
         
        return contiguousPTOCollection;

    };

    if (dateExistsAsPTO(date)) {
        
        var contigousPTOs = __getContiguousPTO(date);

        selectedDates = _.filter(selectedDates,function(item){

            var validItem = true;
            var dateItem  = moment(item).format('MM-DD-YYYY');

            for (var i = contigousPTOs.length - 1; i >= 0; i--) {
                var contItem = moment(contigousPTOs[i]).format('MM-DD-YYYY');
                if( contItem === dateItem){
                    validItem = false;
                    break;
                }
            };

            return validItem;

        });         
       
    }
}

function syncRows(){
    
    var invalidRow = function(id){
        
        var invalid = true;
       
        for (var i = selectedDates.length - 1; i >= 0; i--) {
            var dateId = moment(selectedDates[i]).format('YYYYMMDD');
            if( id === dateId ){
                invalid = false;
                break;
            }
        };

        return invalid;
    };

    var rows = $('#collap1 > .ptoRowDataItem');

    _.each(rows,function(row){ 

        if(invalidRow(row.id)){
          $('#'+ row.id ).remove();
          $('#ERROR-'+ row.id ).remove();
        } 
        
    });

    if (selectedDates.length === 0) {
        $('#ptoDetailsHeader').remove();
        $('#pto-collapsible-set-comment-block').html("");
        $('#submit_click2').addClass('ui-disabled');
    }

    updateSubmitButtonState();

    _.defer(highlightSelectedDates);

}

function removeRow(input) {
 
    var str = null;

    if (_.isUndefined(input.parentNode)) {
    
        str = input;
        $('#'+'ERROR-'+ str ).attr('id');
        $('#' + str).remove();
    
    } else {

        input = input.parentNode;
        str = $(input.parentNode).attr('id');
        $('#'+'ERROR-'+$(input.parentNode).attr('id')).remove();
        $(input.parentNode).remove();

    }

    var dateArray = [];

    var dateToBeRemoved = moment( str.substring(0, 4) + '-' + str.substring(4, 6) + '-' + str.substring(6, 8) , 'YYYY-MM-DD').toDate();
 
    selectedDates = _.filter(selectedDates,function(dt){
        return moment(dt).format("MM-DD-YYYY") !== moment(dateToBeRemoved).format("MM-DD-YYYY")
    });

    syncRows(selectedDates);

}

function getGlobalmy() {
    return myFlag;
}

function getttt() {
    return parseInt(ttt);
}

function getxxx1() {
    return xxx[1];
}

function removeSpaces(string) {
    return removeDot(string.split(' ').join(''));
}

function removeDot(string) {
    return string.split('.').join('');
}

function alertDismissed() {
    // do nothing
}

function generateCalendarView() {
 
}

var date_sort_asc = function (date1, date2) {
    if (date1 > date2) return 1;
    if (date1 < date2) return -1;
    return 0;
};  

function setHolidayHistory(date, inMonth) {
    if (inMonth) {
        var myDate = moment().toDate();
        myDate.setDate(myDate.getDate() - 360);
        for (var i = 0; i < hh.length; i++) {
            
            if (date < myDate) {
                return[false,'HISTORICAL_date'];                
            }

            if (date.getMonth() + 1 == hh[i][0] && date.getDate() == hh[i][1] && date.getFullYear() == hh[i][2]) {
                if (hh[i][3] == "SUBMITTED" || hh[i][3] == "APPROVED" || hh[i][3] == "REJECTED") {
                    return[true,"hh[i][3] + '_day'"];
                    
                } else {
                    return[true,"hh[i][3] + '_day'"];
                    
                }
            }
            if (date.getMonth() + 1 == hh[i][0] && date.getDate() == hh[i][1] && date.getFullYear() == hh[i][2]) {
                if (hh[i][3] == "SUBMITTED" || hh[i][3] == "APPROVED" || hh[i][3] == "REJECTED") {
                    return[true,"hh[i][3] + '_day'"];
                } else {
                    return[true,"hh[i][3] + '_day'"];
                }
            }           
        }
    }
    return [];
}
function fixPTOHistoryJSON() {
    var data;
    if (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data) === '[object Object]') {
        if (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data.history) === '[object Object]') {
            data = eval('[ptoHistory.getPTOHistoryResponse.employeePTO.body.data.history]');
        }
    } else {
        if (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data) === '[object Array]') {
            data = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;
        }
    }
    return data;
}
function processDates() {

    var data = fixPTOHistoryJSON();
    var arLen = data.length;
    for (var i = 0, j = 0, len = arLen; i < len; ++i) {
        if ( parseFloat( data[i].absenceHours ) <= 0) continue;
        if ( _.isNull(data[i].absenceDate ) ){
            break;
        }
        var abdate = data[i].absenceDate;
        var timeCardStatus = data[i].timeCardStatus;
        var dateInMonth = abdate.substring(8, 10);
        historyDates[j] = [abdate.substring(5, 7), dateInMonth, abdate.substring(0, 4), timeCardStatus];
        j++;        
    } 
    
    if( _.isUndefined(holidayCalendar.getHolidayCalendar.employeePTO.body)){
        return [];
    }
    var holidayLen = holidayCalendar.getHolidayCalendar.employeePTO.body.data.holiday.length;

    for (var i = 0, len = holidayLen; i < len; ++i) {
        var holiday = holidayCalendar.getHolidayCalendar.employeePTO.body.data.holiday[i].holidayDate;
        holidayDates[i] = [monthArray[holiday.substring(3, 6)], holiday.substring(0, 2), "20" + holiday.substring(7, 9), "HOLIDAY"];
       ////console.log(holiday);
    }
   //console.log('"Length of original holidayDates'+holidayDates.length+'holiday'+holidayDates);
   var  hh = historyDates.concat(holidayDates);
   // //console.log(hh);
    return hh;
};

$('#rev_land').on("click", function () {
   var months = [ "January", "February", "March", "April", "May", "June", 
           "July", "August", "September", "October", "November", "December" ];

    xxx[0] = months[$("#inlineDatepicker").datepicker('getDate').getMonthName()];
    xxx[1] = $("#inlineDatepicker").datepicker('getDate').getFullYear();

    
    ttt= $("#inlineDatepicker").datepicker('getDate').getMonth();       
                                       
});

function displayGettingStarted() {
    isFirstTimeUser = false;   
    $('#pageTitle').html('Getting Started');
    $('#back').removeClass('displaynone');  
    $('#feedback').addClass('displaynone'); 
    $('#ptoBalRequest').addClass('displaynone');
    $('#gettingStarted').removeClass('displaynone');
}

var setAppStarRating = function (uSR) {
    $.ajax({
        url: "saveRating",
        data: "starRating="+uSR,        
        /*url: "saveRating?starRating=" + uSR,*/
        type: "POST",
        dataType: "json",
        success: function (data) {
            if (data.status === true) {
                alert("Rating Sent Successfully");
                updateAppStarRating(uSR);
            } else {
                alert("Feedback Send Failed\nPlease Try Again Later");
            }
        },
        error: function () {
            alert("Update rating Failed - Service Appears To Be Down\nPlease Try Again Later");
        }
    });
};
function updateAppStarRating(sr) {
    $("#appStarRating").empty();
    var i;
    for (i = 1; i <= 5; i++) {
        if (i <= sr) {
            $("#appStarRating").append(
                $("<a></a>").attr("onclick", "setAppStarRating(" + i + ")")
                .append(
                    $("<img src = '" + staticAssetsMobilePath + "/mobile-static/images/Transparent.png' class='rating-icons star-filled'/>")));
        } else {
            $("#appStarRating").append(
                $("<a></a>").attr("onclick", "setAppStarRating(" + i + ")")
                .append(
                    $("<img src = '" + staticAssetsMobilePath + "/mobile-static/images/Transparent.png' class='rating-icons star-unfilled'/>")));
        }
    }
}

function getAppStarRating() {
    $.ajax({
        url: "rating",
        type: "POST",
        dataType: "json",
        success: function (data) {
            updateAppStarRating(data.rating);
        },
        error: function () {
            alert("Error getting Rating - Service Appears To Be Down\nPlease Try Again Later");
        }
    });
}

function submitFeedback() {
    
    var feedbackText = $('#feedbackText').val();
    
    if (feedbackText.trim() === '' || feedbackText.trim() === 'Insert text here ...') {
        alert("Comment is a required field.");
        return;
    }

    $.ajax({
        url: "saveFeedback?feedback=" + feedbackText,
        type: "POST",
        dataType: "json",
        success: function (data) {
            if (data.status === true) {
                $('#feedbackText').val('');
                alert("Feedback Sent Successfully");
            } else {
                alert("Feedback Send Failed\nPlease Try Again Later");
            }
        },
        error: function (data) {
            alert("Feedback Send Failed - Service Appears To Be Down\nPlease Try Again Later");
        }
    });
}
function getSettingPage(){  
    $('#ptoBalRequest').removeClass('displaynone'); 
    $('#gettingStarted').addClass('displaynone');
    $('#feedback').addClass('displaynone');
}
function toFeedbackPage() {
    $('#pageTitle').html('Feedback');   
    //$('#settings').addClass('displaynone');
    $('#back').removeClass('displaynone');  
    $('#ptoBalRequest').addClass('displaynone');    
    $('#gettingStarted').addClass('displaynone');
    $('#feedback').removeClass('displaynone');
    getAppStarRating();    
}

function highlightSelectedDates() {

    var items = $(".ui-datepicker-calendar td");

    _.each(items, function(item) {

          var handlerName = $(item).data('handler');
    
          if (handlerName === 'selectDay' && !_.isUndefined(handlerName) && !_.isUndefined($(item).data('month')) && !_.isUndefined($(item).data('year'))) {
                var day;
                if (typeof item.textContent !== "undefined") {
                  day = item.textContent.replace(/(\r\n|\n|\r)/gm, "");
                } else {
                  day = item.innerText.replace(/(\r\n|\n|\r)/gm, "");
                }
                var month = $(item).data('month') + 1; // adjusted the index 
                var year = $(item).data('year');

                var _padZero = function(str){
                    return str.toString().length === 1 ? ( '0' + str ) : str;
                };
                var dateString = _padZero(month) + "-" + _padZero( day ) + "-" + year;
                var date = moment(dateString);
                if(selectedDates!= null){
                    /*var existingDate = selectedDates.filter(function(dateItem) {
                     return dateString === moment(dateItem).format("MM-DD-YYYY");
                    });*/
                    var existingDate = selectedDates.filter(function(dateItem) {
                     return dateString === moment(dateItem).format("MM-DD-YYYY");
                    });
                
                    if (existingDate.length > 0) {
                        $(item.firstChild).addClass('SELECTED_day');
                    }else{
                        $(item.firstChild).removeClass('SELECTED_day');
                    }
                }          
          }
    
        });

}

function updateSubmitButtonState(errors) {

    var  hasErrors = $('.validation-error').length !== 0;

    if (!_.isUndefined(selectedDates) && !_.isNull(selectedDates)) {

        if (selectedDates.length > 0 && !hasErrors ) {
            $('#submit_click2').removeClass('ui-disabled');
            $('#submit_click2').prop("disabled", false); //Enable
        } else {
            $('#submit_click2').addClass('ui-disabled');
            $('#submit_click2').prop("disabled", true); //Disable
        }

    }

}

jQuery.noConflict();

$(document).ready(function () { 

    function requestFilter( options, originalOptions){
        
        if( /getPTOComments/.test(originalOptions.url) || originalOptions.disableFilter){
            return {
                action:'comment',
                empty:false
            };
        }
        var urlStr              = originalOptions.url;
        var isUpdate            = /updatePTO/.test(urlStr);
        var isSubmit            = /submitPTO/.test(urlStr);
        var ptoArr              = [];
        var ptoComment          = ""; 
        var historyByStatus     = _.groupBy(ptoHistory.getPTOHistoryResponse.employeePTO.body.data,'timeCardStatus');
        var existingPTOHistory  = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;

        var getPTOCommentFromURL = function( url ) {
            return url.split('&comments=')[1];  
        };

        var buildRequestURL  =  function(type, ptoData, comment ){

            var url = "";
            if( type ==='submit'){
                url = '/mypto/mobile/submitPTO?pto='+JSON.stringify(ptoData)+'&comments='+comment;
            }

            if( type ==='update'){
                url = '/mypto/mobile/updatePTO?pto='+JSON.stringify(ptoData)+'&comments='+comment;
            }

            return url;

        };

        var getPTODataFromURL = function( url ) {

            var ptoJSONFormatted = url.split('?pto=')[1].split('&')[0]; 
 
            
            try{ 
            	 if(country === "IT"){
            		 
            		 try {
            			  ptoJSONFormatted = JSON.parse( ptoJSONFormatted.substring(0, ptoJSONFormatted.length - 2) );
            		 }catch(e){
            			 ptoJSONFormatted = JSON.parse( ptoJSONFormatted.substring(0, ptoJSONFormatted.length - 2)+ ']');
            		 }
            		
            	 }else{
            		 ptoJSONFormatted = JSON.parse( ptoJSONFormatted.substring(0, ptoJSONFormatted.length - 2)+ ']');
            	 }
            	 
            }catch(e){
                 return false;
            }
            

            return ptoJSONFormatted; 

        };
        
        var getNewDatesAndExistingDates =  function( __ptoHistory){

            var newDates  = [];
            var existingDates = [];
            var ptoColl = [];

            for( var i = 0; i < selectedDates.length ; i++){

                var formattedDate     = moment(selectedDates[i]).format('YYYY-MM-DD');                
                var hasNewDate        = _.where( __ptoHistory , {
                    'absenceDate':formattedDate 
                });

                if( hasNewDate.length === 0){
                    newDates.push(formattedDate);
                }else{
                    existingDates.push(formattedDate); 
                     _.forEach(hasNewDate,function(el){
                        ptoColl.push(el);
                     });
                }
            }

            return{
                'NEW_DATES':newDates,
                'EXISTING_DATES':existingDates,
                'EXISTING_PTO_OBJECTS':ptoColl
            };
            // also returning ptoItems from history which are selected
            
        };
        
        var ptoGlobalFilter = function(  __ptoArr, __partitionDates){

           
            var filteredPtoArr = [];

            /*
                'NEW_DATES':newDates,format "2015-11-18"
                'EXISTING_DATES':existingDates,
                'EXISTING_PTO_OBJECTS':ptoColl
            */


            var isNewPTOItem = function(__formattedDate){
                return _.contains( __partitionDates.NEW_DATES, __formattedDate );
            };

            var isExistingPTOItem = function(__formattedDate){
                return _.contains( __partitionDates.EXISTING_DATES, __formattedDate );
            };
            /*date: "11-11-2015"
            hour: "8"
            type: "01 P.T.O"

            absenceDate: "2016-01-28"
            absenceHours: "6"
            hourType: "01 P.T.O."
            timeCardId: "108914668"
            timeCardStatus: "SUBMITTED"*/
            var getCorrespondingHistoryObjectWithStatus = function( __ptoItem, __formattedDate ){
                
                var item = _.findWhere( __partitionDates.EXISTING_PTO_OBJECTS, {
                    "absenceDate":__formattedDate,
                    "hourType":__ptoItem.type
                });

                return !_.isUndefined(item) ? {
                    'item':item,
                    'status':item.timeCardStatus,
                    'isModified':parseFloat(__ptoItem.hour) !== parseFloat(item.absenceHours)
                } : null;

            };

            _.each( __ptoArr, function(ptoItem){

                var formattedDate = moment(ptoItem.date,"MM-DD-YYYY").format("YYYY-MM-DD");

                if( isNewPTOItem(formattedDate) && 0 !== parseFloat( ptoItem.hour )){
                   filteredPtoArr.push(ptoItem);
                }

                if(isExistingPTOItem(formattedDate)){

                    var pObj = getCorrespondingHistoryObjectWithStatus(ptoItem,formattedDate);

                    if( _.isNull(pObj) ){
                        
                        if( 0 !== parseFloat( ptoItem.hour )){
                           filteredPtoArr.push(ptoItem);
                        }

                    }

                    if(!_.isNull(pObj) && ( pObj.status === 'APPROVED' || pObj.status === 'SUBMITTED') ){
                        
                        if( parseFloat( pObj.item.absenceHours ) > 0 ){
                          filteredPtoArr.push(ptoItem);
                        }
                        
                        if( parseFloat( pObj.item.absenceHours ) === 0 && pObj.isModified ){
                          filteredPtoArr.push(ptoItem);
                        }

                    }
 
                }

            });
            
            return filteredPtoArr;

        };

        ptoArr = getPTODataFromURL( urlStr ); 
        _.each( ptoArr, function(item){
            if( item['timeCardID'] === 'undefined'){
                delete item['timeCardID'];
            }
        });

        if(!ptoArr){               
          return {
                action:'pto',
                isEmpty:true
           };
        }

        ptoComment = getPTOCommentFromURL( urlStr );

        var partitionDates = getNewDatesAndExistingDates( existingPTOHistory );
        var hoursForSubmission = ptoGlobalFilter(ptoArr,partitionDates);
        var shouldUpdate   = partitionDates.NEW_DATES.length === 0;

        if(hoursForSubmission.length === 0){
            return {
                action:'pto',
                isEmpty:true
            };
        }
        if(!shouldUpdate){
            options.url = buildRequestURL('submit', hoursForSubmission, ptoComment);
        }

        if(shouldUpdate){
            options.url = buildRequestURL('update', hoursForSubmission, ptoComment);
        }      

        return {
            action:'pto',
            isEmpty:false
        };

    };

    $.ajaxPrefilter(function( options, originalOptions, jqXHR ) {
        var filterStatus = requestFilter(options,originalOptions);
        if( filterStatus.action === 'pto' && filterStatus.isEmpty ){
            jqXHR.abort();
            $('#loadingModal').modal('hide');
            alert("Invalid PTO hours, All fields cannot be 0");
        }

        if( filterStatus.action === 'pto' && !filterStatus.isEmpty  ){
            $('#loadingModal').modal('show');
        }

    });

    if(isMobile()){
        $('body').addClass('mobile-view');
    }

    var hasNoData = function (){
     
         var ptoResponse = pto.getPTOResponse.employeePTO.header;
         var msg         = " Employee Data is not present in HRMS or Employee is Inactive";
         if(  ptoResponse.status === 'Fail' ){
           
           if( ptoResponse.error.errorMessage === msg ){
            return true;
           }

         } 

         return false;

    };

    var isCountrySupported =  function (){
        var supportedCountryList = ["AR","AT","BE","BG","BR","CA","CH","CZ","DE","DK","ES","FI","FR","HU","IE","IL","IT","MX","NL","NO","PE","PT","SA","SE","CA","FR","PT","US","UK","AE","GB"];
        var cc  = _.isNull(pto.getPTOResponse.employeePTO.body) ? "" : pto.getPTOResponse.employeePTO.body.countryCode;
        return _.contains(supportedCountryList,cc);
    };
    
    var isValidEmployeeType = function(){
        var et  = _.isNull(pto.getPTOResponse.employeePTO.body) ? "" : pto.getPTOResponse.employeePTO.body.employeeType;   
        et = _.isUndefined(et) ? "" : et;
        if ( _.isNull( et.match("Non-Exempt") ) ){
            return true;
        }else{
            return false;
        }
    };


    if( hasNoData() ){
       
        var name = "";
        
        if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
            name = ", "+pto.getPTOResponse.employeePTO.body.employeeName;
        }
         
        var ERROR_MSG_UNAUTHORIZED = 'Sorry, you are not authorized to use this application. Please click '+'<a href="https://wwwin-hrprd.cisco.com/OA_HTML/AppsLogin" target="_blank">here</a>'+' to submit your PTO.';
        
        var errorMarkup =  '<div class="container">\
                                            </br>\
                                            <div class="alert alert-info">\
                                              <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                                              <div class="icon-align-middle">\
                                                <strong>'+ ERROR_MSG_UNAUTHORIZED +'</strong>\
                                             </div>\
                                            </div>\
                                         </div>';

        
        $('#ea-app').html(errorMarkup);
        return;

    }
    
    if( !isValidEmployeeType() ){
        
        if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
            name = ", "+pto.getPTOResponse.employeePTO.body.employeeName;
        }
        
        var ERROR_MSG = 'Sorry, you are not authorized to use this application. Please click '+'<a href="https://wwwin-hrprd.cisco.com/OA_HTML/AppsLogin" target="_blank">here</a>'+' to submit your PTO.';
        //var ERROR_MSG = 'Sorry you are not authorized to use this application. Please reach out to <a href="mailto:mypto-support@cisco.com" target="_blank">support</a> for further assistance.';
        
        //var ERROR_MSG = "Sorry"+name+" something went wrong while processing your request. Please reach out to "+'<a href="mypto-support@cisco.com" target="_blank">support</a>'+" for further assistance.";
        //var NO_USER_MSG = "Sorry"+name+", My PTO app is currently not available to you due to some business restrictions. Sorry for the inconvenience. Please click "+'<a href="http://wwwin.cisco.com/c/cec/employee/pto-payroll.html#horizontalTab2" target="_blank">here</a>'+" for the preferred means to submit PTO for your region.";
        var errorMarkup =  '<div class="container">\
                                            </br>\
                                            <div class="alert alert-info">\
                                              <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                                              <div class="icon-align-middle">\
                                                <strong>'+ ERROR_MSG +'</strong>\
                                             </div>\
                                            </div>\
                                         </div>';

        $('#ea-app').html(errorMarkup);

        return;

    }


    if( !isCountrySupported() ){

        var name = "";
        if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
            name = ", "+pto.getPTOResponse.employeePTO.body.employeeName;
        }

        var ERROR_MSG = 'Sorry'+name+' you are not authorized to use this application. Please click '+'<a href="https://wwwin-hrprd.cisco.com/OA_HTML/AppsLogin" target="_blank">here</a>'+' to submit your PTO.';
        
        var errorMarkup =  '<div class="container">\
                                </br>\
                                <div class="alert alert-info">\
                                  <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                                  <div class="icon-align-middle">\
                                    <strong>'+ ERROR_MSG +'</strong>\
                                 </div>\
                                </div>\
                            </div>';

        $('#ea-app').html(errorMarkup);

        return;
    }


    if( !isValidEmployeeType() || !isCountrySupported() || _.isNull(pto.getPTOResponse.employeePTO.body) || _.isUndefined(holidayCalendar.getHolidayCalendar.employeePTO.body)){

        var name = "";
    
        if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
            name = ", "+pto.getPTOResponse.employeePTO.body.employeeName;
        }
    
        var ERROR_MSG = "Sorry"+name+" something went wrong while processing your request. Please reach out to "+'<a href="mypto-support@cisco.com" target="_blank">support</a>'+" for further assistance.";
     
        var errorMarkup =  '<div class="container">\
                                </br>\
                                <div class="alert alert-info">\
                                  <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                                  <div class="icon-align-middle">\
                                    <strong>'+ ERROR_MSG +'</strong>\
                                 </div>\
                                </div>\
                            </div>';

        $('#ea-app').html(errorMarkup);

        return;

    }

   

    if( _.isNull(pto.getPTOResponse.employeePTO.body) || _.isUndefined(holidayCalendar.getHolidayCalendar.employeePTO.body)){

        var name = "";
        if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
            name = ", "+pto.getPTOResponse.employeePTO.body.employeeName;
        }
        var ERROR_MSG = "Sorry "+name+", My PTO app is currently not available for you. Please click "+'<a href="http://wwwin.cisco.com/c/cec/employee/pto-payroll.html#horizontalTab2" target="_blank">here</a>'+" to get the list of preferred options to submit PTO for your region.";
        var errorMarkup =  '<div class="container">\
                            </br>\
                            <div class="alert alert-info">\
                              <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                              <div class="icon-align-middle">\
                                <strong>'+ ERROR_MSG +'</strong>\
                             </div>\
                            </div>\
                         </div>';

        $('#ea-app').html(errorMarkup);
        return;
    }

    removeHistoryDatesWithAllZero();

    var employee_name = pto.getPTOResponse.employeePTO.body.employeeName;
        employee_name = employee_name.split(",").reverse().join(" ");
    //console.log("Employee name - " + employee_name);
        $('.empName').html(employee_name);
        $("#pto-last-payperiod-date").html(pto.getPTOResponse.employeePTO.body.lastPayPeriodDate);
        $("#pto-last-payperiod-date1").html(pto.getPTOResponse.employeePTO.body.lastPayPeriodDate);
        
    //alert('balance page');
    if (pto.getPTOResponse.employeePTO.header.status == "Fail") {
        //display the inactive error message from HRMS
        $('.pto-error-message').html(pto.getPTOResponse.employeePTO.header.error.errorMessage);
        $('.empName').html("");
        $(".hdrTitle2").html("");
        $("#gridBalance1").html("");
        $("#gridBalance2").html("");
        $(".pto-navbar").html("");
    } else {
        //alert("test " + country);
        flag = 0;
        var bal = "";
        var hourTypeUnit = "";
        var ptoType = "";
        var data = "";
        hourTypeUnit = (country == "CA" || country == "US" || country == "JP") ? "Hrs" : "Days";
        ptoType = "PTO Type";
        data = (Object.prototype.toString.call(pto.getPTOResponse.employeePTO.body.data) === '[object Array]') ? (pto.getPTOResponse.employeePTO.body.data) : (eval('[ pto.getPTOResponse.employeePTO.body.data ]'));
        var availableBalanceCaption = "";
        
        if (country == "US" || country == "JP") {
            bal = bal + '<div class="balanceBlock col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding">\
                           <div class="balanceHeader col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding">\
                                <span class="col-xs-3 col-sm-3 col-md-3 col-lg-3 no-padding">'  + ptoType + '</span>\
                                <span class="col-xs-4 col-sm-4 col-md-4 col-lg-4 no-padding">\
                                 <span class=\'col-lg-12 no-padding\' style=\'line-height:1.2\'> \
                                    Total Balance\
                                    <a href=\"https://wwwin-hrprd.cisco.com/OA_HTML/RF.jsp?function_id=48207&amp;resp_id=50597&amp;resp_appl_id=800&amp;security_group_id=29&amp;lang_code=US\" target=\"_blank\" class=\"pto-accural-link\">( Accrual History )</a>\
                                  </span>\
                                    <span class=\'balance-header header-subtext\' style=\'font-size:12px;font-weight:normal;\'> as of ' + pto.getPTOResponse.employeePTO.body.lastPayPeriodDate+ '</span>\
                                </span>\
                                <span class="col-xs-3 col-sm-3 col-md-3 col-lg-3 no-padding">\
                                 <span class=\'col-lg-12 no-padding\' style=\'line-height:1.2\'> \
                                    Available Balance*\
                                    </span>\
                                    <span class=\'balance-header header-subtext\' style=\'font-size:12px;font-weight:normal;\'> to submit </span>\
                                </span>\
                                <span class="col-xs-2 col-sm-2 col-md-2 col-lg-2 no-padding">' + 'Limit' + '</span>\
                            </div>' ;

            for (var i = 0; i < data.length; i++) {
                var limit = (data[i].accrualLimit).toString();
                if (limit.match(/^\d/)) limit += " " + hourTypeUnit;
                else limit = "";
                //bal = bal + "<tr><td style=\"text-align:left; padding-bottom:0.5em; font-weight: bold\" width=\"36%\">&nbsp;&nbsp;" + data[i].accrualType + "</td><td style=\"text-align:right; padding-bottom:0.5em; font-weight: bold\" width=\"20%\">" + (data[i].balance).toFixed(2) + " " + hourTypeUnit + "</td><td style=\"text-align:right; padding-bottom:0.5em; font-weight:bold\"width=\"38%\">" + limit + "&nbsp&nbsp</td></tr>";
                
                var PTO_HOUR_TYPE_KEY = "01 P.T.O.";
                var FLOATING_HOUR_TYPE_KEY = "02 Floating Holiday";
                var TIME_TO_GIVE_KEY = "Time2Give";

                var labelToTypeMap = {
                     "US Paid Time Off":PTO_HOUR_TYPE_KEY,
                     "US Floating Holiday Plan":FLOATING_HOUR_TYPE_KEY,
                     "US Time2Give":TIME_TO_GIVE_KEY
                };

                var availableBalance = {};

                var lastPayPeriodDate = moment(pto.getPTOResponse.employeePTO.body.lastPayPeriodDate).format("YYYY-MM-DD");               

                var ptoHoursGroupedByType = _.groupBy(ptoHistory.getPTOHistoryResponse.employeePTO.body.data,'hourType');


                availableBalance[PTO_HOUR_TYPE_KEY] =  _(ptoHoursGroupedByType[PTO_HOUR_TYPE_KEY]).reduce(function(memo, num){
                      var submittedAfterPayPeriod = moment(num.absenceDate,"YYYY-MM-DD").isAfter(moment(lastPayPeriodDate,"YYYY-MM-DD"));
                      if( ( num.timeCardStatus !== "SUBMITTED" || num.timeCardStatus !== "APPROVED" ) && !submittedAfterPayPeriod) return memo;                  
                      return memo + parseFloat(num.absenceHours).toFixed(2);                  
                },0); 

                availableBalance[FLOATING_HOUR_TYPE_KEY]  =  _(ptoHoursGroupedByType[FLOATING_HOUR_TYPE_KEY]).reduce(function(memo, num){
                      var submittedAfterPayPeriod = moment(num.absenceDate,"YYYY-MM-DD").isAfter(moment(lastPayPeriodDate,"YYYY-MM-DD"));
                      if( ( num.timeCardStatus !== "SUBMITTED" || num.timeCardStatus !== "APPROVED" ) && !submittedAfterPayPeriod) return memo;                  
                      return memo + parseFloat(num.absenceHours).toFixed(2);                  
                },0); 

                availableBalance[TIME_TO_GIVE_KEY] =  _(ptoHoursGroupedByType[TIME_TO_GIVE_KEY]).reduce(function(memo, num){
                      var submittedAfterPayPeriod = moment(num.absenceDate,"YYYY-MM-DD").isAfter(moment(lastPayPeriodDate,"YYYY-MM-DD"));
                      if( ( num.timeCardStatus !== "SUBMITTED" || num.timeCardStatus !== "APPROVED" )  && !submittedAfterPayPeriod) return memo;                  
                      return memo + parseFloat(num.absenceHours).toFixed(2);                  
                },0);


                var getAvailableBalance = function( idx ){
                    return parseFloat(data[idx].balance)-parseFloat(availableBalance[labelToTypeMap[data[idx].accrualType]]).toFixed(2);
                };

                bal = bal + "<div class='balanceBody col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding'>\
                            <span class='col-xs-3 col-sm-3 col-md-3 col-lg-3 no-padding'>" + data[i].accrualType + "</span>\
                            <span class='col-xs-4 col-sm-4 col-md-4 col-lg-4 no-padding'>" + data[i].balance + " " + hourTypeUnit + "</span>\
                            <span class='col-xs-3 col-sm-3 col-md-3 col-lg-3 no-padding'>" + getAvailableBalance(i) + " " + hourTypeUnit + "</span>\
                            <span class='col-xs-2 col-sm-2 col-md-2 col-lg-2 no-padding'>" + limit + "</span>" + "</div>";
            }

            bal = bal + "</div>";
            availableBalanceCaption = '<div class="available-balance-info" style="font-size: 90%;text-align: center;color: #8C8C8C;">*Available balance = Total balance (as of '+ pto.getPTOResponse.employeePTO.body.lastPayPeriodDate +') - hours submitted/approved ( after '+ pto.getPTOResponse.employeePTO.body.lastPayPeriodDate +' )</div>';
            $('#gridBalance1').after(availableBalanceCaption);
            $('#gridBalance2').after(availableBalanceCaption);

          } else {

            bal = bal +
                "<div  class='balanceBlock col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding'>" +
                "<div class='balanceHeader col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding'>\
                <span class='col-xs-8 col-sm-8 col-md-9 col-lg-9 no-padding'>PTO Type</span>\
                <span class='col-xs-4 col-sm-4 col-md-3 col-lg-3 no-padding'>Balance</span></div>";
            for (var i = 0; i < data.length; i++) {

                //bal = bal + "<tr><td  style=\"text-align:left; padding-bottom: 0.5em; font-weight:bold\">&nbsp&nbsp&nbsp" + data[i].accrualType + "</td><td  style=\"text-align:right; padding-bottom: 0.5em; font-weight: bold\">" + (data[i].balance).toFixed(1) + " " + hourTypeUnit + "&nbsp&nbsp&nbsp</td></tr>";
                bal = bal + "<div class='balanceBody col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding'><span class='col-xs-8 col-sm-8 col-md-9 col-lg-9 no-padding'>" + data[i].accrualType + "</span><span class='col-xs-4 col-sm-4 col-md-3 col-lg-3 no-padding'>" + data[i].balance + " " + hourTypeUnit + "</span></div>";
            }
            bal = bal + "</div>";

        }
        
       
        $('#gridBalance1').html(bal);
        $('#gridBalance2').html(bal);   
  

        $("#gridBalance1 th").css("font-size", Math.round(windowWidth * (5 / 100))); // 5% font-size for dtlHdr
        $("#gridBalance1 tr").css("font-size", Math.round(windowWidth * (3.5 / 100))); // 5% font-size for dtlHdr
   
    }

    
 $('.datepick-month-header').css('padding-left', 2 + '%');
   
function fixPTOHourTypeJSON() {
    var data;
    if (Object.prototype.toString.call(hourType.getHourTypeResponse.employeePTO.body.data) === '[object Object]') {
        if (Object.prototype.toString.call(hourType.getHourTypeResponse.employeePTO.body.data.row) === '[object Object]') {
            data = eval('[hourType.getHourTypeResponse.employeePTO.body.data.row]');
        }
    } else {
        if (Object.prototype.toString.call(hourType.getHourTypeResponse.employeePTO.body.data) === '[object Array]') {
            data = hourType.getHourTypeResponse.employeePTO.body.data;
        }
    } 
    return data;
}
function isApprovedDate(date){ 
    var __ptoHistory = fixPTOHistoryJSON();
    var formattedDate = moment(date).format('YYYY-MM-DD');
    return  _.where(__ptoHistory,{'absenceDate':formattedDate,'timeCardStatus':'APPROVED'}).length !== 0;
} 
function isSubmittedDate(date) {
    //var data = (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data) === '[object Array]') ? (ptoHistory.getPTOHistoryResponse.employeePTO.body.data) : (eval('[ ptoHistory.getPTOHistoryResponse.employeePTO.body.data ]'));
    var data = fixPTOHistoryJSON();
    var arLen = data.length;
    for (var i = 0, len = arLen; i < len; ++i) {
        if ( date === data[i].absenceDate &&  parseFloat( data[i].absenceHours ) >= 0) {
            return true;
        }
    }
    return false;
}
function getSubmittedDate(date, hourType) {
    //var data = (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data) === '[object Array]') ? (ptoHistory.getPTOHistoryResponse.employeePTO.body.data) : (eval('[ ptoHistory.getPTOHistoryResponse.employeePTO.body.data ]'));
    var data = fixPTOHistoryJSON();

    var arLen = data.length;
    ////console.log("arLen -- " + arLen);
    for (var i = 0, len = arLen; i < len; ++i) {
        //if (date == data[i].absenceDate && hourType == data[i].hourType &&  parseFloat( data[i].absenceHours ) > 0) {
       // //console.log("date -- " + date + " data[i].absenceDate -- " + data[i].absenceDate + " hourType -- " + hourType + " data[i].hourType -- " + data[i].hourType + "  parseFloat( data[i].absenceHours ) -- " +  parseFloat( data[i].absenceHours)) ;
       // date -- 20152015-11-09 data[i].absenceDate -- 2015-05-27 hourType -- Standard Vacation data[i].hourType -- Standard Vacation  parseFloat( data[i].absenceHours ) -- 1
        if (date == data[i].absenceDate && hourType == data[i].hourType &&  parseFloat( data[i].absenceHours ) >= 0) {
            return data[i];
        }
    }
    return "";
}

function getPTOComments(effectiveDate, status) {
     
    var getPTOCommentsRequestData = "effectiveDate=" + effectiveDate + "&status=" + status;
    //var getPTOCommentsURL = "/hrmobile/mobile/getPTOComments?"+getPTOCommentsRequestData;
    //var getPTOCommentsURL = "../mobile/getPTOComments?" + getPTOCommentsRequestData;
    /*
        DE23493
    */
    var userid = getQueryStrings('userid').userid;
    var userIdQueryString = _.isUndefined(userid)?"":'?userid='+userid;
    var getPTOCommentsURL = serviceBasePath+"/getPTOComments"+userIdQueryString;
    
    $.ajax({
        type: "POST",
        url: getPTOCommentsURL,
        data: {
                'effectiveDate': effectiveDate,
                'status' : status
        },      
        dataType: "json",
        success: function (data) {
            // $.unblockUI();
            //console.log(data);

            if( data.COMMENTS === "undefined" || _.isUndefined(data.COMMENTS) || _.isNull(data.COMMENTS) ){
                $('#pto-textarea-comment').val("");
            }else{
                $('#pto-textarea-comment').val(data.COMMENTS);
            }

            

        },
        error: function (data) {
           // $.unblockUI();
            //console.log(data);
            alert(INTERNAL_SERVER_ERROR);
        }
    });
}

 
$('#submit_click2').on('click', function (event) {
 
    if( this.className === "ui-disabled" ){
        event.preventDefault();
        return;
    }

    isSubmitClicked = true; 
 
/*  var checkValidValues = true;

    $.each($('.ptoinput'), function () {

        if ( jQuery.trim($(this).val()) == '' || (jQuery.trim($(this).val()) != '' && parseInt(jQuery.trim($(this).val())) < 0)) {
            
            alert("Invalid values found!!! Please input a valid value or 0");
            $(this).focus();
            checkValidValues = false;
            return;

        }

    });*/
    isPTOformValid = $('.validation-error').length === 0;

    if ( isPTOformValid ) {

        isSubmitClicked = true;

        $('#submit_click2').css('cursor','progress');
        $("#ptoForm").submit();

    } else {
        alert("Please fix the errors marked with red.");
        event.preventDefault();
    }
    //$("#ptoForm").submit();
    //  $('#submit_click2').unbind('click');
    //  $('#submit_click2').bind('click');
});

function isDateAlreadyApproved(date){
   
    var isApproved = false;
   
    _.each(historyDates,function(dateItem){
        var itemDate   = _.flatten(dateItem).slice(0,3).join('-');
        var itemStatus = _.flatten(dateItem).slice(3).join('-');
       
        if( itemDate === date && itemStatus === "APPROVED"){
            isApproved = true;
        }

    });

    return isApproved;
}

function formatDateToYYYYMMDD(date){

    
    if(typeof date !== 'string'){
        date = moment(date).format('MM-DD-YYYY');
    }
    var dateArr    = date.split('-');
    var dateString = dateArr[2]+'-'+dateArr[0]+'-'+dateArr[1];
  
    return dateString;

}


function getContiguousPTO(date) {
    // from selected date, go backwards until we reach a non-PTO, non-weekend, non-holiday, then do the same forwards
    // date: Date object
    // returns array of dates strings YYYY-MM-DD, eg 2010-05-09
    var contigDates = [];
    var contig = false;
    var beforeDates = [];
    // get prior contiguous days
    var before = 0;
    var contigCount = 0;

 //   var dateYYYYMMDD = formatDateToYYYYMMDD(date);
    var dateYYYYMMDD =  null;
    
          
    dateYYYYMMDD = moment(date,'MM-DD-YYYY').format('YYYY-MM-DD'); 


    //var dateYYYYMMDD =  moment(date).format('YYYY-MM-DD');  // e.g. 2010-12-22
    //console.log('dateYYYYMMDD'+dateYYYYMMDD);
    var dayCounter = 0;
    var ptoItemsBeforeSelectedDates = [];
    while(true){
        
        var prevDate = moment(dateYYYYMMDD).subtract( ++dayCounter , 'days').toDate();

         // if its a weekend or weekday then stop going
        if( !isWeekday(prevDate) ){
            break;
        } 

        if( isWeekday(prevDate) && !isDateAlreadyPTO(prevDate)){
            break;
        }
         
       
        if( isDateAlreadyPTO(prevDate) ){
           ptoItemsBeforeSelectedDates.push(prevDate);  
        }

    }
    
    dayCounter = 0;
    var ptoItemsAfterSelectedDates = [];
    while(true){
        
        var nextDate = moment(dateYYYYMMDD).add( ++dayCounter , 'days').toDate();

         // if its a weekend or weekday then stop going
        if( !isWeekday(nextDate) ){
            break;
        } 

        if( isWeekday(nextDate) && !isDateAlreadyPTO(nextDate)){
            break;
        }
                
        if( isDateAlreadyPTO(nextDate) ){
           ptoItemsAfterSelectedDates.push(nextDate);  
        }

    }
 
    var contiguousPTOCollection = _.uniq(_.union(ptoItemsBeforeSelectedDates, ptoItemsAfterSelectedDates), false );
    
    return contiguousPTOCollection;
    
    
    /*do {

        //var prevDate = Date.parse(dateYYYYMMDD).addDays(-(1 + before));
        var prevDate = moment(dateYYYYMMDD).subtract( ( 1 + before) , 'days').toDate();

        contig = false;
        //if((!isWeekday(prevDate)) || isDateHoliday(prevDate) || isDateAlreadyPTO(prevDate)) {
        if (( isWeekday(prevDate)) || isDateAlreadyPTO(prevDate)) {
            contig = true;
            before++;
            if (isDateAlreadyPTO(prevDate)) {
                //console.log("pto: prev date: " + prevDate);
                beforeDates[contigCount++] = prevDate;
            }
        }
    } while (contig);

    // get following contiguous days
    var afterDates = [];
    var after = 0;
    contigCount = 0;

    do {
        // get next day
        //var nextDate = Date.parse(dateYYYYMMDD).addDays((1 + after));
        var nextDate = moment(dateYYYYMMDD).add( (1 + after) , 'days').toDate();
        contig = false;
        //if((!isWeekday(nextDate)) || isDateHoliday(nextDate) || isDateAlreadyPTO(nextDate)) {
        if (( !isWeekday(nextDate)) || isDateAlreadyPTO(nextDate)) {
            contig = true;
            after++;
            if (isDateAlreadyPTO(nextDate)) {
                //console.log("pto: next date: " + nextDate);
                afterDates[contigCount++] = nextDate;
            }
        }
    } while (contig);
    //Create one list in date order
    var i;
    var j = 0;
    for (i = beforeDates.length - 1; i >= 0; i--) {
        contigDates[j++] = beforeDates[i];
    }
    contigDates[j++] = date;

    for (i = 0; i < afterDates.length; i++) {
        contigDates[j++] = afterDates[i];
    }
    //console.log(contigDates.toString());

    return contigDates;*/
}
function isDateAlreadyPTO(date) {


    var i;
    /*var formattedInputDate = new Date(date).toDateString();
    var dateYYYYMMDD = moment( formattedInputDate).format('YYYY-MM-DD'); // e.g. 2010-12-22
    
    
    */
    var hist = fixPTOHistoryJSON();
    var ddDate = moment(date).isValid() ? moment(date).toDate() : moment(date,'MM-DD-YYYY').toDate();
    var formattedDate =  pto_FormatDate( 'YYYY-MM-DD' ,ddDate);
    return _.where(hist,{'absenceDate':formattedDate}).length > 0 ? true : false;   
    //var ad = moment(date,'MM-DD-YYYY').toDate();

    //.format('YYYY-MM-DD'); 
    //dateYYYYMMDD = $.datepicker.formatDate('');
    //var dateYYYYMMDD =  pto_FormatDate( 'YYYY-MM-DD' ,ad);
    //console.log(dateYYYYMMDD);
    //var hist = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;
    /*var hist = fixPTOHistoryJSON();
//console.log(hist.length);
    if (hist.length != 'undefined') {
        for (i = 0; i < hist.length; i++) {
            // ignore null ptoHist records
            if (hist[i].absenceDate !== null) {
                if (dateYYYYMMDD.match(hist[i].absenceDate)) {
                    return true;
                }
            }
        }
    }
    return false;*/
}
function addOrRemoveDateObj(date) {
    if (isDateAlreadyPTO(date)) {
        
        var contigousPTOs = getContiguousPTO(date);
        _.each( contigousPTOs, function(obj){           
            if( !dateAlreadySelected(obj) ){
                selectedDates.push(moment(obj).toDate());
            } 
        }); 

        selectedDates = selectedDates.sort(date_sort_asc);
       
    }
}
function dateAlreadySelected(date){
    
    if( typeof date === 'string' ){
        date = moment(date,'MM-DD-YYYY').toDate();
    }
    for (var i = selectedDates.length - 1; i >= 0; i--) {
       // if(  $.datepicker.formatDate( "yy-mm-dd", new Date(selectedDates[i] ) ) ===  $.datepicker.formatDate( "yy-mm-dd", new Date( date ) ) ){
         
        if( moment(date).format('YYYY-MM-DD') === moment(selectedDates[i]).format('YYYY-MM-DD') ){
           return true;
        } 
    }
    return false;
}
function validateHours(c, hourCode) {
    var countryCode = pto.getPTOResponse.employeePTO.body.countryCode;
    // business validation - PTO hours for OTL Countries - US, Canada and Japan
    if (countryCode == 'US' || countryCode == 'CA') {
        return ((c >= "0") && (c <= "8"));
    } else if (countryCode == 'JP') {
        if (hourCode == "9" || hourCode == "21" || hourCode == "22" || hourCode == "26" || hourCode == "42" ||
            hourCode == "3" || hourCode == "18" || hourCode == "30" || hourCode == "31" || hourCode == "45") {
            // Only allow the following hours for PTO & Substitute leave
            if (c == 0 || c == "1" || c == "2" || c == "3" || c == "4" || c == "5" || c == "6" || c == "7" || c == "7.5") {
                return true;
            } else {
                return false;
            }
        } else if (hourCode == "27" || hourCode == "61" || hourCode == "62" || hourCode == "40" || hourCode == "41") {
            // PTO (Half day), Leave for attending Hospital (Half-Day), Child Care Leave(a half day) hour type validation for Japan
            // 27 PTO (Half day); 61 Leave for attending Hospital (Half-Day); 40, 41 Child Care Leave(a half day); 62 Substitute Leave (Half day)
            if (c == "3.75") {
                return true;
            } else {
                return false;
            }
        } else {
            //Only allow 7.5 for all the other Japan Leave types
            if (c == "7.5") {
                return true;
            } else {
                return false;
            }
        }
    } else if ( countryCode == 'BR' || countryCode == 'MX' || countryCode == 'HU' || countryCode == 'PE') {
        // business validation - PTO days for OAM countries AR, BR, MX, HU and PE
        // allow one day PTO submission 
        if (c == "0" || c == "1") {
            return true;
        } else if(parseFloat(c) % 1 != 0){
            //DE23651       
            alert("Valid values are 0 or 1.");      
            return false;
        }
    } else {
        // business validation - PTO days for rest of the OAM countries
        // allow half day PTO submission (0.5 or .5 days)
        if (c == "0" || c == "1" || c == "0.5" || c == ".5") {
            return true;
        } else {
            return false;
        }
    }
}




function findPTORecord(dateStr, hrtype) {
    var i;
    //var hist = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;
    var hist = fixPTOHistoryJSON();
    for (i = 0; i < hist.length; i++) {
        ////console.log(" hist[i].absenceDate " + hist[i].absenceDate + " dataStr " + dateStr + " hist[i].hourType " + hist[i].hourType + " hrtype " + hrtype);
        if (hist[i].absenceDate != null && hist[i].absenceDate.match(dateStr) && hist[i].hourType === hrtype) {
            //console.log();
            return hist[i];
        }
    }
    return null;
}

// returns false if a weekend
function isWeekend(date) {
    
    var weekend;

    if (country == 'IL' || country == 'AE') {
        weekend = date.getDay() === 5 || date.getDay() === 6;
        return [weekend, weekend ? 'NONWORKING_day' : ''];

    } 

    if (country == 'SA') {
        // For Saudi, Thursday and Friday is the weekend
        weekend = date.getDay() === 5 || date.getDay() === 6;
        return [weekend, weekend ? 'NONWORKING_day' : ''];

    } 

    weekend = date.getDay() === 0 || date.getDay() === 6;
    return [weekend, weekend ? 'NONWORKING_day' : ''];

}

function isWeekday(date) {
    return !isWeekend(date)[0];
}

function getPTOData() {
        var i, h;
        var countryCode = pto.getPTOResponse.employeePTO.body.countryCode;
        //var hourtypeTokens = hourType.getHourTypeResponse.employeePTO.body.data;
        var hourtypeTokens = fixPTOHourTypeJSON();
        var comment = $('#pto-textarea-comment').val();
        if (comment == "Insert a message to your manager regarding this PTO.") {
            comment = null;
        }
        var nonzero = false;
        var err = false;
        var jsondata = "",
            jsondata1 = "";
        for (i = 0; i < selectedDates.length; i++) {

            for (h = 0; h < hourtypeTokens.length; h++) {

                var ptoDIVId     = $.datepicker.formatDate('yymmdd', selectedDates[i]);
                var dateMMDDYYYY = $.datepicker.formatDate('mm-dd-yy', selectedDates[i]);
                var dateYYYYMMDD =  pto_FormatDate( 'YYYY-MM-DD' , selectedDates[i]); // e.g. 2010-08-29
                //var inputName = removeSpaces(hourtypeTokens[h].type);
                if (country == "US" || country == "CA" || country == "JP") {
                    var inputName = removeSpaces(hourtypeTokens[h].code);
                } else {
                    var inputName = removeSpaces(hourtypeTokens[h].type);
                }

                var hrs  = document.getElementById(ptoDIVId + "-" + inputName).value;

                if( hrs==="0" && country !== "US" && country !== "CA" && country !== "JP"){
                    hrs = "";
                } 
              /*  var code = document.getElementById("hourcode" + i + "_" + h).value;
                var type = document.getElementById("hourtype" + i + "_" + h).value;*/

                var getRowIndex =  function (id){
                   return  $('#'+id).find('[name^=hourcode]')[0].name.split('_')[0].replace('hourcode','');
                }

                var code = document.getElementById("hourcode" + getRowIndex( ptoDIVId ) + "_" + h).value;
                var type = document.getElementById("hourtype" + getRowIndex( ptoDIVId ) + "_" + h).value; 


                ////console.log("ptoDIVId " + ptoDIVId + "timecardid value " + document.getElementById("timecardid"+ptoDIVId).value);
                ////console.log("timecardid " + "timecardid"+i+"_"+h);

                var timecardidElement = document.getElementById("timecardid" + ptoDIVId);
                if (timecardidElement !== null) {
                    var timecardid = document.getElementById("timecardid" + ptoDIVId).value;
                }

                // This was commented out for fixing DE19280.
                // When multiple absence type was supported, timecardid is empty if we use the below line
                //var timecardid = document.getElementById("timecardid"+i+"_"+h).value;

                // For update PTO, send timecardid as well
                //console.log("isUpdate " + isUpdate);
                if (isUpdate === true) {
                    
                    window.isResubmit = false;
                    
                    if (country == 'US' || country == 'CA' || country == 'JP') {
                        jsondata1 = ("{\"date\":\"" + dateMMDDYYYY + "\",\"hour\":\"" + hrs + "\",\"type\":\"" + code + "\",\"timeCardID\":\"" + timecardid + "\"},");
                    } else {
                        jsondata1 = ("{\"date\":\"" + dateMMDDYYYY + "\",\"hour\":\"" + hrs + "\",\"type\":\"" + type + "\",\"timeCardID\":\"" + timecardid + "\"},");
                    }
                 
                    var historyObj = findPTORecord(dateYYYYMMDD, type);
                 
                    if (historyObj !== null) {
                        //console.log("hrs " + hrs + "; historyObj.absenceHours " + historyObj.absenceHours);
                        //if((hour == historyObj.absenceHours) && changedComment == CISCO.iwe.wfs.pto.logic.comments) {
                        var rejectedPTO = false;
                        
                        if( !_.isUndefined(historyObj.timeCardStatus) ){
                            rejectedPTO = historyObj.timeCardStatus === 'REJECTED' ? true : false;
                        }
                        
                        if ((hrs == historyObj.absenceHours) && !rejectedPTO ) {
                            // don't submit if we have a matching ptoHistory record and hours are unchanged
                            window.isResubmit = true;
                        }

                    } else {
                        //console.log("hrs " + hrs);

                        /*if (hrs == "0") {
                            // otherwise don't submit if we have no matching PTO history record and hours are zero
                            jsondata1 = "";
                        }*/
                    }
                    //console.log("json data1 " + jsondata1);
                    //console.log("json data " + jsondata);

                    jsondata += jsondata1;

                } else {
                    // Send only the hours that has a value
                    // Previously all the zero values were sent which submits PTO for all hour types.
                    if (hrs != "") {
                         if (validateHours(hrs, code) ) {
                            //if (hrs != "0") {
                                if (country == 'US' || country == 'CA' || country == 'JP') {
                                    jsondata += ("{\"date\":\"" + dateMMDDYYYY + "\",\"hour\":\"" + hrs + "\",\"type\":\"" + code + "\"},");
                                } else {
                                    jsondata += ("{\"date\":\"" + dateMMDDYYYY + "\",\"hour\":\"" + hrs + "\",\"type\":\"" + type + "\"},");
                                }
                            //}
                         }
                    }
                }
            }
        }
        if (isUpdate === true && (country == "IT" || country == "ES" || country == "BR")) {
            /*
                FIX FOR TIMECARD
        */
            if (jsondata != '') {
                var newJSON = jsondata || {};
                if (jsondata[jsondata.length - 1] == ',') {
                    newJSON = '[' + jsondata.substr(0, jsondata.length - 1) + ']';
                }

                newJSON = JSON.parse(newJSON);

                if (newJSON.length > 0) {
                    for (var key in newJSON) {
                        if (newJSON[key].hour == 1) {
                            newJSON[key].timeCardID = '0';
                        }
                    }
                }
                jsondata = JSON.stringify(newJSON);
                jsondata = jsondata.substring(jsondata.substr(0, jsondata.length - 1)) + ",]";
            }
        } else {
            jsondata = "[" + jsondata + "]";
        }
        // trim the new line characters and then encode comments
        if (comment != null) {
            comment = comment.trim();
            // if completely trimmed, send the comment as null as required by backend
            if (comment.length == 0) {
                comment = null;
            } else {
                // escape double quotes, new line characters as required by backend
                comment = comment.replace(/[\n]/g, '\\n');
                comment = comment.replace(/[\r]/g, '\\r');
                comment = comment.replace(/[\t]/g, '\\t');
                comment = comment.replace(/[\b]/g, '\\b');
                comment = comment.replace(/[\f]/g, '\\f');
                comment = comment.replace(/"/g, '\\"');
            }
        }
        comment = encodeURIComponent(comment);
        //jsondata += ",\"COMMENTS\":\"" + comment + "\"";
        //jsondata += "}";

        var submitPTOURLData = "pto=" + jsondata + "&comments=" + comment;
        return submitPTOURLData;
}




function getStatusForSelectedDate(date) {
    //console.log("getStatusForSelectedDate " + date);
    var data = fixPTOHistoryJSON();
    var arLen = data.length;
    for (var i = 0, len = arLen; i < len; ++i) {
        if (date == data[i].absenceDate) {
            //console.log("getStatusForSelectedDate - " + data[i].timeCardStatus);
            return data[i].timeCardStatus;
        }
    }
    //console.log("getStatusForSelectedDate - empty Status");
    return "";
}

    var countryCode = pto.getPTOResponse.employeePTO.body.countryCode;
    var start = new Date();
    start.setFullYear(start.getFullYear() - 1);
    var end = new Date();
    end.setFullYear(end.getFullYear() +1);
    
    
    if ($( window ).width()< 600)
        var noOfMonths=1;
    else
        var noOfMonths=3;

    function getMonthCountByDevice(){
        
        var months = 3;
        var widowWidth = $( window ).width();
        
        if( widowWidth > 768 ){
            months = 3;
        }

        if( widowWidth < 780 ){
            months = 2;
        }

        if( widowWidth <= 420 ){
            months = 1;
        }

        return months;
    }
    
    function showWarnings(){
        
/*        $('.alert-warning').remove();
        
        var warningAlertForApproved = "<div class=\"alert-warning\">This action will resubmit the approved PTO again</div>";

        _.forEach(selectedDates,function(date){
            
            var isApproved = isApprovedDate(date);
                
            if(isApproved){
              
              if(!$('#'+moment(date).format('YYYYMMDD')).hasClass('APPROVED_PTO')){
                $('#'+moment(date).format('YYYYMMDD')).addClass('APPROVED_PTO');
               }
              
               $('#'+moment(date).format('YYYYMMDD')).append(warningAlertForApproved);
            }   

        });*/
                

    }
   
    var defaultDate = lastSubmittedDate !== "" ? moment(lastSubmittedDate,"MM-DD-YYYY").toDate() : (new Date());

    $('#inlineDatepicker').datepicker({
        dateFormat: "mm-dd-yy",
        defaultDate: defaultDate, // in case of a submit show the latest submitted date.
        changeMonth: false,
        numberOfMonths:getMonthCountByDevice(),
        dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'],
        onDate: setHolidayHistory(),
        showOtherMonths: true,
        minDate: moment(start).toDate(),
        yearRange: start.getFullYear() + ':' + end.getFullYear(),   
        // onShow: function (inst) {
            // i = getGlobalI();
            // var i1 = i - 1;
            // var i2 = i + 1;
            // var stra = '+' + i1 + 'm';
            // var strb = '+' + i2 + 'm';
            
            // $('.datepick-today').removeClass('datepick-highlight');
            // //var data = (Object.prototype.toString.call(ptoHistory.getPTOHistoryResponse.employeePTO.body.data) === '[object Array]') ? (ptoHistory.getPTOHistoryResponse.employeePTO.body.data) : (eval('[ ptoHistory.getPTOHistoryResponse.employeePTO.body.data ]'));
            // var data = fixPTOHistoryJSON();
            // var arLen = data.length;
            // for (var i = 0, len = arLen; i < len; ++i) {
                // var abdate = data[i].absenceDate;
                // if (abdate == null) continue;
                // abdate = abdate.replace(/-/g, '/');
                // var absenceDate = new Date(abdate);
                // var abDateString = $.datepick.formatDate('DD, M d, yy', absenceDate);
                // var timeCardStatus = data[i].timeCardStatus;

                // $('a[title="Select ' + abDateString + '"]').removeClass('SUBMITTED_day');
                // $('a[title="Select ' + abDateString + '"]').removeClass('APPROVED_day');
                // $('a[title="Select ' + abDateString + '"]').removeClass('REJECTED_day');
                // //if ( parseFloat( data[i].absenceHours ) &&  parseFloat( data[i].absenceHours ) > 0) {
                // if ( parseFloat( data[i].absenceHours ) &&  parseFloat( data[i].absenceHours ) >= 0) {
                    // $('a[title="Select ' + abDateString + '"]').addClass(timeCardStatus + "_day");
                    // //console.log(abDateString);
                // }
            // }

            // $('.datepick-selected').removeClass('SUBMITTED_day');
            // $('.datepick-selected').removeClass('APPROVED_day');
            // $('.datepick-selected').removeClass('REJECTED_day');
            // $('.datepick').css('font-size', 2 + windowWidth * .49 + '%');
            // $('.datepick-month-header').css('padding-left', 29 + '%');
            // $('.datepick').css('width', windowWidth - 5 + 'px');
           // // fixForiPhone();
            // $('.datepick').css('max-width', windowWidth + 'px');
        // },
        onSelect: function (dates,inst) { 

            // if date is already approved
            /* if( isDateAlreadyApproved(dates) ){
                return;
            }
            */
            //  console.log("Before onSelect:"+ moment().format("HH:mm:ss") );

            if(isDateRejectedPTO(dates)){

                var result = confirm("This action will reset the Rejected status and open up the dates for submitting PTO's again. Do you want to proceed ?");
                if (result) {
                   handleRejectedPTOSelect(dates);
                }                 
                return;
            }

            var dateRowId = dates.substring(6) + dates.substring(0, 2) + dates.substring(3, 5);

            if ( $('#' + dateRowId).length ) {
                removeRow(dateRowId);
                return;
            }

            var date = $(this).datepicker('getDate');

            //Empty selectedDatesTemp if it's not
            //selectedDates = (typeof selectedDates != 'undefined' && selectedDates instanceof Array) ? selectedDates : [];
            selectedDates = _.isUndefined(selectedDates) || _.isNull(selectedDates) ? [] : selectedDates;
            //if(jQuery.inArray( date, selectedDates ) )
            var i = 0,
                dateArr = [];
            
            _.each(selectedDates, function(item) {
                dateArr[i] = item.toString();
            });
            
            var found = jQuery.inArray(date.toString(), dateArr);
            
            if (found < 0) {
                selectedDates.push(date); 
            }

            //console.log(selectedDates);
            selectedDates = selectedDates.sort(date_sort_asc);
            sel_land = selectedDates;
            // enable the Create Request button
          
            addOrRemoveDateObj(dates);

            //console.log("End onSelect:"+ moment().format("HH:mm:ss") );
           //return[false,"SELECTED_day",''];                             
        
        },
        afterUpdate:function(){  

            //console.log("After update:"+ moment().format("HH:mm:ss") );
            highlightSelectedDates();
            updateSubmitButtonState();    
            showWarnings();
            applySpinners();
               
        },
        onChangeMonthYear: function (year, month, inst) {
            var i1 = i - 1;
            var i2 = i + 1;
            var strp = '+' + i + 'm';
            var stra = '+' + i1 + 'm';
            var strb = '+' + i2 + 'm';
           
        },
        beforeShowDay: function(date) {         
            
            // console.log("start beforeShowDay:"+ moment().format("HH:mm:ss") );

            var hhDates = processDates();
            var holidayList = [],
                holidayType = [];
            for (var i = 0; i < hhDates.length; i++) {
                //"mm-dd-yy",
                holidayList[i] = hhDates[i][0] + '-' + hhDates[i][1] + '-' + hhDates[i][2];
                holidayType[i] = hhDates[i][3];
            }

            flag = 0;
            var value = '';
            var inDate = '';
            var grid = '';
            var isSubmitInput = '<input type="hidden" name="isSubmit" id="indate' + i + '" value="true" />';
            var timeCardIDHiddenHTML = '';
            isSubmitClicked = true;

            var collap = '';
            var box = '';
            if (selectedDates != null) {

                $('#submit_click2').removeClass('ui-disabled');
                var hourCodes = new Array();
                ptoHourType = fixPTOHourTypeJSON();
                ////console.log(ptoHourType);
                var ptoHType = ptoHourType;
                var hourTypeLen = ptoHourType.length;
                setCurHourType(hourTypeLen);

                var selectedDateMMDDYYYY = moment(date).format('MM-DD-YYYY');//date$.datepicker.formatDate('mm-dd-yy', selectedDates[0]);
                //alert(selectedDates[0]+'000'+selectedDateMMDDYYYY);
                // Check for contiguous PTO dates for Update PTO
                //addOrRemoveDateObj(selectedDates[0]);

                for (var j = 0, len = hourTypeLen; j < len; ++j) {
                    var inputName = removeSpaces(ptoHourType[j].type);
                    if ((inputName).match(/PTO/)) {
                        hourCodes[j] = "PTO";
                    } else if ((inputName).match(/FloatingHoliday/)) {
                        hourCodes[j] = "FH";
                    } else if ((inputName).match(/Bereavement/) || (inputName).match(/Bereavment/)) {
                        hourCodes[j] = "BV";
                    } else if ((inputName).match(/JuryDuty/)) {
                        hourCodes[j] = "JD";
                    } else if ((inputName).match(/CompensationDays/)) {
                        hourCodes[j] = "CT";
                    } else if ((inputName).match(/StandardVacation/) || (inputName).match(/Standard Vacation/)) {
                        hourCodes[j] = "SV";
                    } else if ((inputName).match(/CiscoVacation/) || (inputName).match(/Cisco Vacation/)) {
                        hourCodes[j] = "CV";
                    } else if ((inputName).match(/SocialSecurityVacation/) || (inputName).match(/Social Security Vacation/)) {
                        hourCodes[j] = "SSV";
                    } else if ((inputName).match(/SavingsPlan/) || (inputName).match(/Savings Plan/)) {
                        hourCodes[j] = "SP";
                    } else if ((inputName).match(/WorkTimeReductionLeave/) || (inputName).match(/Work Time Reduction Leave/)) {
                        hourCodes[j] = "WTR";
                    } else if ((inputName).match(/SalaryContinuationPlan/)) {
                        hourCodes[j] = "SCP";
                    } else if ((inputName).match(/VacationSold/)) {
                        hourCodes[j] = "VS";
                    } else if ((inputName).match(/SavingsVacation/)) {
                        hourCodes[j] = "SGV";
                    }
                }
                //console.log(selectedDates.length+'====='+selectedDates);
                for (var i = 0; i < selectedDates.length; i++) {
                    ////console.log("date:===>" + .datepicker.formatDate(selectedDates[i], "E MM/dd/y"));
                    var inputHTML = "";
                    var hourTypeLen = ptoHourType.length;
                    ////console.log('ptohourtypelength'+hourTypeLen);
                    var hourValue = 0;
                    var maxlength = "";
                    maxlength = (country == "CA" || country == "US" || country == "JP") ? "4" : "6";
                    var ptoDIVId = $.datepicker.formatDate('yymmdd', selectedDates[i]); 

                    var isDateSubmitted = isSubmittedDate( pto_FormatDate( 'YYYY-MM-DD' , selectedDates[i]));

                    if (isDateSubmitted === true) {
                        $('#submit_click2').addClass('ui-disabled');
                        isUpdate = true;
                    } else {
                        isUpdate = false;
                    }

                    var displayDate = $.datepicker.formatDate('dd', selectedDates[i]);
                    // isDateSubmitted will be true only if atleast one of hourtype absenceHours is > 0
                    // isDateSubmitted will be false if its a new date or if date is submitted with 0 hours (to be treated as new date)
                    // var totalHour = 0;

                    totalHour = 0.0;

                    var tableHeader = '';

                    for (var j = 0, len = hourTypeLen; j < len; ++j) {
                        
                        var stripLeadingNumbers = function(str){
                        /*  str = str.split(' ');
                            if(str.length>1){  
                                str.shift();
                                return str.join(' ');
                            }*/
                            if(/Time2Give/.test(str)){
                                return str.replace(/(Time2Give)[0-9]/g, '').trim();
                            }
                            return str.replace(/[0-9]/g, '').trim();
                        };
                        
                        if (i == 0) {
                            var cl = (j == 0) ? "<div class='col-lg-3'>PTO dates</div>" : '';
                            tableHeader += cl + "<div style='min-width: 110px' class='col-xs-12 col-lg-1 hidden-xs visible-lg no-padding'>" +
                                "<div class='font14px padBottom10 text-center'>" + stripLeadingNumbers(ptoHourType[j].type) + "</div></div>";
                        }


                        ////console.log("Type========>" + ptoHourType[j]);
                        if (country == "US" || country == "CA" || country == "JP") {
                            var inputCode = removeSpaces(ptoHourType[j].code);
                        } else {
                            var inputCode = removeSpaces(ptoHourType[j].type);
                        }
                        var inputName = removeSpaces(ptoHourType[j].type);
                        //var inputName = ptoHourType[j];
                        // //console.log("inputname -- " + inputName);
                        var submitted = getSubmittedDate( pto_FormatDate( 'YYYY-MM-DD' , selectedDates[i]), ptoHourType[j].type);
                        //console.log("submitted -- " + submitted);

                        // Default value based on hour type and hour code
                        /*if (ptoHourType[j].type.indexOf("P.T.O") > 0) {
                            hourValue = "8";
                        } else if (ptoHourType[j].type.indexOf("Standard") > 0 || ptoHourType[j].type == "Standard Vacation") {
                            hourValue = "1";
                        } else if (country == 'JP' && (ptoHourType[j].code == '9' || ptoHourType[j].code == '21' ||
                                ptoHourType[j].code == '22' || ptoHourType[j].code == '26' || ptoHourType[j].code == '42')) {
                            // code 9, 21, 22, 26 and 42 is for 'PTO' for Japan
                            // For Japan, the default value is 7.5 hours
                            hourValue = "7.5";
                        } else {
                            hourValue = "0";
                        }*/
                        if (!(isSubmitClicked) && $('#' + ptoDIVId + "-" + inputCode) && $('#' + ptoDIVId + "-" + inputCode).val()) {
                            hourValue = parseFloat($('#' + ptoDIVId + "-" + inputCode).val());
                        } else {
                            hourValue = parseFloat((isDateSubmitted) ? ((submitted != "") ? submitted.absenceHours : "0") : ((j == 0) ? ((country == "CA" || country == "US") ? "8" : "1") : "0"));
                            if (country == "JP") {
                                hourValue = parseFloat((isDateSubmitted) ? ((submitted != "") ? submitted.absenceHours : "0") : ((j == 0) ? ((country == "JP") ? "7.5" : "1") : "0"));
                            }
                        }

                        // DE19404
                        if (ptoHourType[j].type == "Standard Vacation" && country == "BR") {
                            hourValue = 1;
                        }
                        if (ptoHourType[j].type == "Vacation Sold" && country == "BR") {
                            hourValue = 0;
                        }
                        ////console.log("Hour value would be " + hourValue);
                        totalHour += parseFloat(hourValue);
                        settotalHour(totalHour);
                        var timeCardID = (submitted == "") ? "" : submitted.timeCardId;
                        var timeCardStatus = (submitted == "") ? "" : submitted.timeCardStatus;
                        if (timeCardID != "") {
                            timeCardIDHiddenHTML = "<input type=\"hidden\" name=\"timecardid" + ptoDIVId + "\" id=\"timecardid" + ptoDIVId + "\" value=\"" + timeCardID + "\" />";
                        } else {
                            timeCardIDHiddenHTML = "";
                        }
                        //console.log($('#collap1').children().length);

                        inputHTML = inputHTML +
                            "<div class='col-xs-12 col-lg-1 text-center no-padding pto-hour-type-row'>" +
                            "<div class='col-xs-8 hidden-lg pto-hour-type'> <span>" + ptoHourType[j].type + "</span> </div>" +
                            "<div id=\"inputIdBal" + i + "_" + j + "\" class=\"col-md-12 col-xs-4\">" +
                            "<input class=\"form-control pto-row-input\" type=\"number\" data-hourcode=\"" + ptoHourType[j].code + "\" name=\"" + inputCode + i + "\" style=\"border-color: #cecece;border-radius: 3px;\" data-timecardstatus=\"" +
                            timeCardStatus + "\" id=\"" + ptoDIVId + "-" + inputCode + "\" value=\"" + hourValue + "\" size=\"4\" maxlength=\"" + maxlength + "\" class=\"ptoinput\" min='0' max='8'/>" + //max='" + hourValue + "'/>" +
                            "</div>" +
                            "<input type=\"hidden\" name=\"hourtype" + i + "_" + j + "\" id=\"hourtype" + i + "_" + j + "\" value=\"" + ptoHourType[j].type + "\" />" +
                            "<input type=\"hidden\" name=\"hourcode" + i + "_" + j + "\" id=\"hourcode" + i + "_" + j + "\" value=\"" + ptoHourType[j].code + "\" />" +
                            "<input type=\"hidden\" name=\"timecardid" + i + "_" + j + "\" id=\"timecardid" + i + "_" + j + "\" value=\"" + timeCardID + "\" />" +
                            timeCardIDHiddenHTML +
                            "</div>";
                    }
                    collap = collap +
                        "<div class='col-lg-12 no-padding ptoRow ptoRowDataItem' id=\"" + ptoDIVId + "\" style='padding:5px 0'>" +
                        "<div class='col-xs-12 col-sm-12 col-md-12 col-lg-3' style='padding: 0 0 0 10px;'><b>" + $.datepicker.formatDate('MM', selectedDates[i]) + " " + displayDate + "</b>";
                    //var dis = "none";
                    hourValue = 0;
                   
                    for (var j = 0, len = hourTypeLen; j < len; ++j) {
                        
                        var inputName = removeSpaces(ptoHourType[j].type);
                        //dis = (hourValue >= 0) ? "inline" : "none";
                        var submitted = getSubmittedDate($.datepicker.formatDate('yy-mm-d', selectedDates[i]), ptoHourType[j].type);
                        //console.log("submitted  " + submitted);
                        ////console.log("parseFloat((isDateSubmitted)  " + parseFloat(isDateSubmitted));
                        ////console.log("submitted.absenceHours  " + submitted.absenceHours);
                        hourValue = parseFloat(hourValue) + parseFloat((isDateSubmitted) ? ((submitted != "") ? submitted.absenceHours : "0") : ((j == 0) ? ((country == "CA" || country == "US" || country == "JP") ? "8" : "1") : "0"));
                        if (country == "JP") {
                            hourValue = parseFloat(hourValue) + parseFloat((isDateSubmitted) ? ((submitted != "") ? submitted.absenceHours : "0") : ((j == 0) ? ((country == "JP") ? "7.5" : "1") : "0"));
                        }
                        // //console.log("hourValue-" + hourValue);
                        /*dis = (j == 0 && (hourValue >= 0)) ? "inline" : "none";
                        collap = collap +
                            "<span id=\"" + ptoDIVId + "-" + inputName + "Display\"  style=\"display:" + dis + ";\">" +
                            "<pto class=\"ptofont\" id=\"" + ptoDIVId + "-" + inputName + "display\" >" + totalHour + "</pto>" +
                            "</span>";*/
                        collap = collap + " ";
                    }

                    collap = collap + "</span></div>";

                    var ptoDetailsHeaderExists = function(){
                        return $('#ptoDetailsHeader').length === 0 ? false : true;
                    }
                    if( !ptoDetailsHeaderExists() ){
                        
                        $('#collap1').before("<div id='ptoDetailsHeader' class='col-lg-12 no-padding ptoRow bold'>" + tableHeader + "</div>");

                    } 
               
                    collap += inputHTML;
                   
                    var __hideButtonBasedOnStatus = function(){
                        return isDateSubmitted ? 'submitted-date' : '';
                    }               
                    
                    collap = collap + "<div class=\"col-xs-12 col-lg-1 text-center no-padding\"> <input type=\"hidden\" name=\"inputdate" + i + "\" id=\"inputdate" + i + "\" data-isDateSubmitted = \"" + isDateSubmitted + "\" value=\"" + $.datepicker.formatDate(selectedDates[i]) + "\" />" +
                        "<button  onclick='removeRow(this)' class='pto-remove-btn btn-responsive "+__hideButtonBasedOnStatus()+"'> <i class='cisco-icon cisco-icon-delete-10091-h27-w27 cisco-icon-autohover' id='deleteIcon'></i>  </button>  </div> </div>";

                }

                $('#collap1').html(collap + isSubmitInput);
                $('#collap1').trigger("create");

                var getPTOCommentsStatus = getStatusForSelectedDate( moment(date).format('YYYY-MM-DD') );
                // Call getPTOComments AJAX
                if ( getPTOCommentsStatus != "" && dateAlreadySelected(selectedDateMMDDYYYY) ) {
                    ////console.log("Call PTO Comments - getPTOCommentsStatus " + getPTOCommentsStatus);
                    getPTOComments(selectedDateMMDDYYYY, getPTOCommentsStatus);
                } else {
                    //console.log("getPTOCommentsStatus " + getPTOCommentsStatus);
                    $('#submit_click2').removeClass('ui-disabled');
                }


                var commentCollapsible = '<div id="pto-collapsible-set-comment" class="col-lg-12 no-padding" style="padding:15px 0;">' + '  <div class="pto-textarea-comment">' + ' <textarea name="pto-textarea-comment" id="pto-textarea-comment" class="col-lg-12 form-control" placeholder="Insert a message to your manager regarding this PTO"></textarea>' + '       </div>' + '</div>';

                $('#pto-collapsible-set-comment-block').html(commentCollapsible);
                $('#pto-collapsible-set-comment-block').trigger("create");

                $("#pto-textarea-comment").focus(function() {
                    $("#pto-textarea-comment").addClass("pto-textarea-active");
                    var comment = $("#pto-textarea-comment").val();
                    if (comment == "Insert a message to your manager regarding this PTO.") {
                        //$("#pto-textarea-comment").attr("value", "");
                        $("#pto-textarea-comment").val("");
                        $("#pto-textarea-comment").addClass("pto-comment-text");
                    }
                });

                $("#pto-textarea-comment").blur(function() {
                    $("#pto-textarea-comment").removeClass("pto-textarea-active");
                    var comment = $("#pto-textarea-comment").val();
                    if (comment == "" || comment == "null") {
                        //$("#pto-textarea-comment").attr("value", "Insert a message to your manager regarding this PTO");
                        $("#pto-textarea-comment").val("Insert a message to your manager regarding this PTO.");
                        $("#pto-textarea-comment").removeClass("pto-comment-text").addClass("pto-comment-placeholder");
                    }
                });

                
                //$('#datesDetails').html(collap);

            }
            
            var validateJapanHourType = function (inputId, c, hourCode) {
                //alert("c " + c);
                //alert("hourCode " + hourCode);
                if (hourCode == "9" || hourCode == "21" || hourCode == "22" || hourCode == "26" || hourCode == "42" ||
                    hourCode == "3" || hourCode == "18" || hourCode == "30" || hourCode == "31" || hourCode == "45") {
                    // Only allow the following hours for PTO & Substitute leave
                    if (c == "0" || c == "1" || c == "2" || c == "3" || c == "4" || c == "5" || c == "6" || c == "7" || c == "7.5") {
                        $('#submit_click2').removeClass('ui-disabled');
                        return true;
                    } else {
                        //return false;
                        alert("Valid values are whole number in the range of 0-7 or 7.5.");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    }
                } else if (hourCode == "27" || hourCode == "61" || hourCode == "62" || hourCode == "40" || hourCode == "41") {
                    // PTO (Half day), Leave for attending Hospital (Half-Day), Child Care Leave(a half day) hour type validation for Japan
                    // 27 PTO (Half day); 61 Leave for attending Hospital (Half-Day); 40, 41 Child Care Leave(a half day); 62 Substitute Leave (Half day)
                    if (c == "0" || c == "3.75") {
                        $('#submit_click2').removeClass('ui-disabled');
                        return true;
                    } else {
                        //return false;
                        alert("Valid values are 0 or 3.75");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    }
                } else {
                    //Only allow 7.5 for all the other Japan Leave types
                    //if (c == "0" || c == "7.5" || c == "7" || c == "7.") { //onkeyup
                    if (c == "0" || c == "7.5") { //onblur
                        $('#submit_click2').removeClass('ui-disabled');
                        return true;
                    } else {
                        //return false;
                        alert("Valid values are 0 or 7.5");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    }
                }
            };

            var updatePTODisplay = function (inputId, hourCode) {
                isSubmitClicked = false;
                var value = parseFloat($('#' + inputId).val(), 10);
                if (country == "US" || country == "CA") {
                    if (!(value == 0 || value == 1 || value == 2 || value == 3 || value == 4 || value == 5 || value == 6 || value == 7 || value == 8)) {
                        alert("Valid values must be a number in the range 0-8.");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    } else if ($('#' + inputId).attr('data-timecardstatus') == "" && !(value == 0 || value == 1 || value == 2 || value == 3 || value == 4 || value == 5 || value == 6 || value == 7 || value == 8)) {
                        alert("Valid values must be a number in the range 0-8.");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    } /*else {
                        $('#submit_click2').removeClass('ui-disabled');               
                    }*/
                } else if (country == "JP") {
                    validateJapanHourType(inputId, value, hourCode);
                } else if (country == "AR" || country == "BR" || country == "MX" || country == "HU" || country == "PE") {
                    // business validation - PTO days for OAM countries AR, BR, MX, HU and PE
                    if (value == "0" || value == "1" || parseFloat(value) > 0) {
                        $('#submit_click2').removeClass('ui-disabled');
                        $('#' + inputId).val(value);
                    } else {
                        /*showMessage("PTO Request", "Valid values are 0 or 1", {
                            warning: true,
                            showCancel: false
                        });*/

                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    }
                    /*if (value == "0") {
                        jQuery('input#' + inputId).prop('disabled', true);
                    }*/
                } else {
                    totalHour = gettotalHour();
                    if (parseFloat(totalHour) > 1.0) {
                    } else if (!(value == 0 || value == 0.5 || value == 1)) {
                        alert("Valid values are 0, 0.5 or 1");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    } else if ($('#' + inputId).attr('data-timecardstatus') == "" && !(value == 0 || value == 0.5 || value == 1)) {
                        alert("Valid values are 0, 0.5 or 1");
                        $('#' + inputId).val("");
                        $('#submit_click2').addClass('ui-disabled');
                    } else {
                        $('#submit_click2').removeClass('ui-disabled');
                    }
                }   
                
            };

            //$('.ptoinput').keyup(function (event) {
            $('.ptoinput').blur(function (event) {
                $('#submit_click2').removeClass('ui-disabled');
                var id = event.currentTarget.id;
                //var hourcode = event.currentTarget.hourcode;
                var hourcode = $(this).data("hourcode");
                updatePTODisplay(id, hourcode);
                var date = id.substring(0, 8);
                var value = 0,
                    multipleAbsenceTypeCount = 0;
                ptoHourType = fixPTOHourTypeJSON();
                for (var j = 0, len = hourTypeLen; j < len; ++j) {
                    //var value = 0;
                    //var inputName = removeSpaces(ptoHourType[j].type);
                    if (country == "US" || country == "CA" || country == "JP") {
                        var inputName = removeSpaces(ptoHourType[j].code);
                    } else {
                        var inputName = removeSpaces(ptoHourType[j].type);
                    }
                    //var inputName = removeSpaces(ptoHourType[j].code);
                    inputName = date + "-" + inputName;
                    console.log("inputName ----" + inputName);
                    //alert("inputName " + $('#' + inputName).val());
                    if (parseFloat($('#' + inputName).val()) >= 0) {
                        value += parseFloat($('#' + inputName).val());
                        if (!(country == "US" || country == "CA" || country == "JP")) {
                            if (parseFloat($('#' + inputName).val()) > 0) {
                                multipleAbsenceTypeCount++;
                            }
                            if (parseFloat(value) > 0 && multipleAbsenceTypeCount > 1) {
                                alert("Multiple absence type not allowed, total applied value should not be greater than 1");
                                                       
                                value -= parseFloat($('#' + inputName).val());
                                $('#' + id).val("0");
                                $('#submit_click2').addClass('ui-disabled');
                                return;
                            }   
                        }
                    }
                }
                if (!(country == "US" || country == "CA" || country == "JP")) {
                    //DE23780
                    if(value > 1 || (value % 1 != 0 && (country == "AR" || country == "BR" || country == "MX" || country == "HU" || country == "PE"))){
                        alert("Valid values are 0 or 1.");                          
                        $('#submit_click2').addClass('ui-disabled');
                    }           
                }
                console.log("update hours ---- " + value);
                var inputName2 = date + "-" + removeSpaces(ptoHourType[0].type);
                $('#' + inputName2 + 'display').html(value);
                $('#' + inputName2 + 'Display').css('display', 'inline');
            });

            $('.ptoinput').keyup(function (event) {
                $('#submit_click2').removeClass('ui-disabled');
            });

            $('.ptoinput').each(function (index) {
                updatePTODisplay($(this).attr('id'), $(this).attr('data-hourcode'));
                if(isUpdate === true){
                    //Disable the submit button on update mode
                    $('#submit_click2').addClass('ui-disabled');
                }
            });
        
            var formattedDate = $.datepicker.formatDate('mm-dd-yy',date);
            var isNotHoliday = (holidayList.indexOf(formattedDate)==-1);
            var daysType = holidayType[holidayList.indexOf(formattedDate)];
            var holidayClassName =  isNotHoliday?'':((( daysType == 'HOLIDAY')?'ui-datepicker-unselectable ui-state-disabled ':'')+daysType+'_day');
                  
            if (country == 'BR') {
                //enable weekend
                 var weekend = date.getDay() == 0 || date.getDay() == 6;
                     return [!weekend, weekend ? 'NONWORKING_day' : holidayClassName];        

            } else if (country == 'IL' || country == 'AE') {
                var weekend = date.getDay() == 5 || date.getDay() == 6;
                    return [!weekend, weekend ? 'NONWORKING_day' : holidayClassName];
                
            } else if (country == 'SA') {
                // For Saudi, Thursday and Friday is the weekend
                var weekend = date.getDay() == 5 || date.getDay() == 6;
                    return [!weekend, weekend ? 'NONWORKING_day' : holidayClassName];
                
            } else {
                 var weekend = date.getDay() == 0 || date.getDay() == 6;
                     return [!weekend, weekend ? 'NONWORKING_day' : holidayClassName];                
            }

            _.defer(highlightSelectedDates);
                
        }       
    });
     $("#ptoForm").submit(function (e) {
        e.preventDefault();
        dataString = $("#ptoForm").serialize(); 
        ga('send', 'event', 'pto', 'submit', pto.getPTOResponse.employeePTO.body.employeeName);  
        var dateString = "";
        var ajaxURL = "";
        var firstZeroHours = false;
        var inputName1 = "";
        if (selectedDatesTemp != null) {            
            ptoHourType = fixPTOHourTypeJSON();
            var hourTypeLen = ptoHourType.length;
            //alert("hour-len-"+hourTypeLen);
            setCurHourType(hourTypeLen);
            for (var i = 0; i < selectedDatesTemp.length; i++) {
                var ptoDIVId = $.datepicker.formatDate('yymmdd', selectedDatesTemp[i]);
                var isDateSubmitted = $('#inputdate' + i).attr('data-isDateSubmitted');
                ////console.log("isDateSubmitted : " + isDateSubmitted);
                if (isDateSubmitted == "false") {
                    var totalHours = 0;
                    for (var j = 0, len = hourTypeLen; j < len; ++j) {
                        //console.log("timecardid" + i + "_" + j + " : " + $('#timecardid' + i + "_" + j).val());
                        //var inputName = removeSpaces(ptoHourType[j].type);
                        if (country == "US" || country == "CA" || country == "JP") {
                            var inputName = removeSpaces(ptoHourType[j].code);
                        } else {
                            var inputName = removeSpaces(ptoHourType[j].type);
                        }
                        if (j == 0) inputName1 = inputName;
                        if ($('#' + ptoDIVId + "-" + inputName).val().split(' ').join('').length == 0) {
                            $('#' + ptoDIVId + "-" + inputName).val('0');
                        }
                        totalHours += parseFloat($('#' + ptoDIVId + "-" + inputName).val());
                        ////console.log("totalHours -- " + totalHours);
                    }
                    if (totalHours == 0) {
                        if (!firstZeroHours) {
                            focus = ptoDIVId + "-" + inputName1;
                            firstZeroHours = true;
                        }
                        dateString += $.datepicker.formatDate(selectedDatesTemp[i]) + ", ";
                    }
                }
            }
        }
        if (selectedDates == null || selectedDates.length == 0) {
           // $.unblockUI();
            // Move to balance page
            alert("Please select the dates before submitting.");
            $('#balance_page').trigger("click");
            //          e.stopPropagation();
        } else {
            //console.log("dateString---" + dateString);
            dateString = dateString.substring(0, dateString.length - 2);
            ////console.log("dateString-" + dateString);
            if (dateString != "") {
                alert("please enter values for date : " + dateString);
                ////console.log("focus " + focus);
                ////console.log("div -- " + focus.substring(0, 8));
                $('#' + focus.substring(0, 8)).trigger('expand');
                $('#' + focus).focus();
                return false;

                // 2013 July release - To fix DE19279 following business rule is commented
                /*}
             if ((country == "AR" || country == "PT" || country == "MX" || country == "CH") && !isValueSame(dataString)) {
                alert("Half day and one day cannot be submited together.");
            } else if (country == "SE" && !isValueSame2(dataString)) {
                alert("Half day and one day cannot be submited together.");
            } else if (country == 'BR' && doBothPlanTypeshaveValue(dataString)) {
                alert("VS or SV. Cannot be both.");*/
                // 2013 July release - To fix DE19279 following business rule is commented
            } else {
                ////console.log("dataString " + dataString);
                // Send submit PTO data similar to portlet
                var jsonData = getPTOData();
                //DE23651       
                if(jsonData === false) {
                    return false;
                } else {
                    
                    split = jsonData.split('&');

                    var obj = {};
                    for(var i = 0; i < split.length; i++){
                        var kv = split[i].split('=');
                        obj[kv[0]] = decodeURIComponent(kv[1] ? kv[1].replace(/\+/g, ' ') : kv[1]);
                    }

                    /*        
                    if(obj.pto == "[]" || obj.pto == []) {
                        var isOkayToSubmit = confirm("Do you want to submit your PTO without any changes ?");
                        if(!isOkayToSubmit)
                            return false;
                    }*/

                    var haveRegularDates = function(data){
                         
                        var hasRegularDates     = false;
                        var existingPTOHistory  = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;
                        var ptoHistoryForSubmit = jsonData.split('&')[0].replace('pto=','');
                        ptoHistoryForSubmit     = JSON.parse( ptoHistoryForSubmit.substring(0, ptoHistoryForSubmit.length - 2)+ ']'); 

                        for( var i = 0; i < ptoHistoryForSubmit.length ; i++){
                            
                            var histItem              = ptoHistoryForSubmit[i];
                            var formattedDate         = moment(histItem.date,'MM-DD-YYYY').format('YYYY-MM-DD');
                            var type                  = histItem.type;
                            var found = _.where( existingPTOHistory, {
                                'absenceDate':formattedDate,
                                'hourType':type
                            });

                            if(found.length === 0){
                                hasRegularDates = true;
                                break;                                 
                            }

                           
                        }

                        return hasRegularDates;

                    };

                    var submittedPTOHoursNotModified = function(data){
                         
                        var modifiedFlag        = true;
                        var containsOnlyNewDates= false;
                        var existingPTOHistory  = ptoHistory.getPTOHistoryResponse.employeePTO.body.data;
                        var ptoHistoryForSubmit = jsonData.split('&')[0].replace('pto=','');
                        
                        try{
                           ptoHistoryForSubmit  = JSON.parse( ptoHistoryForSubmit.substring(0, ptoHistoryForSubmit.length - 2)+ ']'); 
                        }catch(e){
                           ptoHistoryForSubmit = [];
                        }
                        // handle malformed json string
                        if(ptoHistoryForSubmit.length === 0 ){
                            try{
                                ptoHistoryForSubmit = jsonData.split('}]')[0].split('[{')[1];
                                 
                                ptoHistoryForSubmit = JSON.parse(  '[{'+ptoHistoryForSubmit+'}]' );
                            }
                            catch(e){
                                ptoHistoryForSubmit = [];
                            }
                        }
                        var newDates            = [];
                        
                        for( var i = 0; i < selectedDates.length ; i++){
                            var formattedDate     = moment(selectedDates[i]).format('YYYY-MM-DD');
                            var hasNewDate        = _.where( existingPTOHistory, {
                                'absenceDate':formattedDate 
                            });
                            if( hasNewDate.length === 0){
                                newDates.push(formattedDate);
                            }
                        }

                        if( newDates.length === selectedDates.length ){
                            return false;
                        }

                        for( var i = 0; i < ptoHistoryForSubmit.length ; i++){
                            
                            var histItem              = ptoHistoryForSubmit[i];
                            var formattedDate         = moment(histItem.date,'MM-DD-YYYY').format('YYYY-MM-DD');
                            var type                  = histItem.type;
                            var found = _.where( existingPTOHistory, {
                                'absenceDate':formattedDate,
                                'hourType':type
                            });

                            if(found.length>0){

                                var existingAbsenceHours = _.isUndefined(found[0].absenceHours) ? 0 : found[0].absenceHours;
                                var currentAbsenceHours  = _.isUndefined(histItem.hour) ? 0 : histItem.hour;
                               
                                if( parseFloat(existingAbsenceHours) !== parseFloat(currentAbsenceHours) ){
                                    modifiedFlag =  false; 
                                }

                            }

                           
                        }

                        return modifiedFlag;

                    };

                    var rowsNotModified = submittedPTOHoursNotModified(jsonData);

                    if( rowsNotModified ){
                        var isOkayToSubmit = confirm("Do you want to submit your PTO without any changes ?");
                        if(!isOkayToSubmit)
                            return false;
                    }

              /*      if( window.isResubmit ) {
                        var isOkayToSubmit = confirm("Do you want to submit your PTO without any changes ?");
                        if(!isOkayToSubmit)
                            return false;
                    }*/
                    
                }
                /*$.blockUI({
                    message: '<img src="../mobile-static/images/loader.gif"/>'
                });*/               
                var userid = getQueryStrings('userid').userid;
                var userIdQueryString = _.isUndefined(userid)?"":'&userid='+userid;
                if (isUpdate === true) {
                    ajaxURL = serviceBasePath+"/updatePTO?" + jsonData + userIdQueryString;
                } else {
                    ajaxURL = serviceBasePath+"/submitPTO?" + jsonData + userIdQueryString;  
                }              
                //
             
                ajaxURL += ( '&dateSubmitted=' + moment(_.last(_.sortBy(selectedDates))).format('MM-DD-YYYY') );

                $.ajax({
                    type: "POST",
                    url: ajaxURL,
                    //data: jsonData,
                    dataType: "json",
                    success: function (data) {
                       // $.unblockUI();
                        //alert(data.message);
                       //alert(data.message);
                        //ptoHistory = $.parseJSON(data.getPTOHistoryResponse);

                        if( data.status === 'Failed'){
                        
                            showModal({
                                type:'error',
                                message:data.message
                            });
                            $('#loadingModal').modal('hide');
                            return;
                        
                        }else{

                            ptoHistory = data;                            
                            var selectedCell = $('.datepick-selected');
                            var selectedCellLen = selectedCell.length;
                            for (var ii = 0; ii < selectedCellLen; ii++) {
                                $('.datepick-selected').trigger("click");
                            }
                           
                            var classNames = 'col-lg-12';
                                /* $("<span/>",{"id":'SuccessMsg',
                                               "class":classNames,
                                               "style":"color:green"}).prependTo(".wrap");
                                $('#SuccessMsg').html(document.createTextNode( "PTO submitted Successfully. " ));   */
                            $('#datesDetails').remove();
                            $('#pto-collapsible-set-comment-block').html("");
                            $('#submit_click2').addClass('ui-disabled');
                            $("html, body").animate({ scrollTop: 0 }, "slow");
                           
                            showModal({
                                type:'success',
                                message:data.message
                            });

                        }
                        $('#loadingModal').modal('hide');
                       
                           // window.location.reload()
                    },
                    error: function (data) {
                        $('#loadingModal').modal('hide');
                        alert( INTERNAL_SERVER_ERROR );
                       
                    }
                });
            }
        }
    });  
        
 

    function applySpinners(){
       
        var rowInputType     = getRowInputTypeByCountry(country);
        $('.pto-row-input').on('focusout',function(event){  

            var isValidPTOHour = function(vs){
                 return /^(?:\d*\.\d{1,2}|\d+)$/.test(vs) ? true :false;
            };
            
            var stripLeadingNumbers = function(str){ 
                return str.replace(/(Time2Give)[0-9]/g, '').trim();
            };
            
            var hourCode = stripLeadingNumbers( $(event.target).data('hourcode') );
            hourCode = hourCode === "" ? "input": hourCode;
            var alertMsg = "";
            
            if(!isValidPTOHour(event.target.value) || parseInt(event.target.value) > 8 || event.target.value.trim() === ""){
               
                /*alertMsg = "Invalid value for "+hourCode+". Value is out of range";
                   
                alert(alertMsg); */                     
       
                event.target.value = 0;
                
            }
          
        });
        $( ".pto-row-input" ).spinner({
                min: rowInputType.min,
                max: rowInputType.max,
                step: rowInputType.increment,
                numberFormat: "n",
                change: function( event, ui ) {
            
                    var step                = $( this ).spinner( "option", "step" );
                    var valid               = $( this ).spinner( "isValid" );
                   
                    var stripLeadingNumbers = function(str){ 
                        return str.replace(/(Time2Give)[0-9]/g, '').trim();
                    };
                    
                    var hourCode = stripLeadingNumbers( $(event.target).data('hourcode') );
                    
                    hourCode = hourCode === "" ? "input": hourCode;
                    
                    if( !valid ){
                        
                        var alertMsg = "";
                        
                        if( _.isNaN( $( this ).spinner( "value") ) ){
                            $( this ).spinner( "value", 0 );                              
                        }               
                        
                         

                            var rowValidation = validateRowInput(event.target,step,rowInputType.unit);    
                            renderErrors(event.target,rowValidation.errors);                       
                            updateSubmitButtonState(rowValidation.errors.length !== 0 );
                            $(this).val(event.target.value);

                                                      
                        
                    }else{

                        var rowValidation = validateRowInput(event.target,step,rowInputType.unit);    
                        renderErrors(event.target,rowValidation.errors);                       
                        updateSubmitButtonState(rowValidation.errors.length !== 0 );
                        $( this ).spinner( "value", event.target.value ); 
                        
                    }                             
                
                },
                spin: function( event, ui ) { }
        });
         
    }

    function getParentRow(target){
        return $(target).parent().parent().parent().parent();
    }


    function validateRowInput(target,step,type){

        var errors = [];

        var parentRow = getParentRow(target);

        var rowInputItems = parentRow.find('.pto-row-input');

        var rowInputItemsSum = 0;

        _.each( rowInputItems,function(item){

            rowInputItemsSum += parseFloat(item.value);
 
        });     
 
        if( type === 'hours' && rowInputItemsSum > 8.0 ){
            errors.push({ 
                'message' : 'Total number of hours cannot be more than 8.'
            });
        }
        else if( type=== 'days' && rowInputItemsSum > 1){
            
            errors.push({ 
                'message' : 'Your PTO request cannot be more than 1 day.'
            });

        } 

        if( type === 'days' && ( country === "PE" || country === "AR" || country === 'BR' || country === 'MX' || country === 'DE' || country === 'FR' ) && ( rowInputItemsSum > 0 && rowInputItemsSum < 1 ) ){
            
            errors = [];
            errors.push({ 
                'message' : 'Your PTO request should be either 1 or 0 day.'
            });

        }          

       
        var time2Give = $(parentRow).find('[data-hourcode$=Time2Give]');

        if(time2Give.length>0){
           
           time2Give= time2Give[0];

            if( parseFloat(time2Give.value)%1 !== 0 ){
              errors = [];
              errors.push({ 
                   'message' : 'USA Time2Give hours should be in hourly increments.'
              });    
            }
           
           if( (parseInt(time2Give.value) > 0 ) && (parseInt(time2Give.value) <= 1 )){
               errors = [];
               errors.push({ 
                 'message' : 'USA Time2Give hours should be minimum 2 hours.'
               });   
            }

              
         }

        return {
            'targetId':parentRow.attr('id'),
            'success':errors.length === 0 ? true : false,
            'errors':errors
        };

    }

    function renderErrors(target,errors){
       
        var parentRow = getParentRow(target);
        
        var errorMessage = "";

        _.each( errors, function(errorItem){
            errorMessage += errorItem.message;
        });
         
        var options = {
            title:"Invalid Input",
            placement:'top',
            content: errorMessage,
            viewport:'body'
        };
      
        var errorMessageId = 'ERROR-'+parentRow.attr('id');
        $('#'+errorMessageId).remove();
        if( errors.length > 0){
            $('#'+ parentRow.attr('id') ).after('<div id="'+errorMessageId+'" class="validation-error">'+errorMessage+'</div>');
        } 
        
    }
    
     
});


function getRowInputTypeByCountry(countryCode){
    
    var type = getHourTypeUnit();

    var typeObj = {
        unit:'hours',
        min:0,
        max:8,
        increment:1
    };
    
    var isCountry = function(code){
        return country === code;
    };

    if(type === 'hours'){

        typeObj = {
            unit:'hours',
            min:0,
            max:8,
            increment:1
        };

    }

    if( type === 'days' ){

        typeObj = {
            unit:'days',
            min:0,
            max:1,
            increment:0.5
        };
        
    }

    if( type === 'days' ){

        typeObj = {
            unit:'days',
            min:0,
            max:1,
            increment:0.5
        };
        
    }

    if( type === 'days' && ( isCountry("BR") || isCountry("AR") || isCountry("PE") || isCountry("MX") || isCountry('DE') || isCountry('FR') ) ){

        typeObj = {
            unit:'days',
            min:0,
            max:1,
            increment:1
        };
        
    }

    /*if( type === 'days' && isCountry("AR")  ){

        typeObj = {
            unit:'days',
            min:0,
            max:1.4,
            increment:0.2
        };
        
    }*/
 
    return typeObj;
}


var vacationMeasureUnitLookup = {
    'US':{
        unit:'hours',
        min:0,
        max:8,
        increment:1
    },

};


function getHourTypeUnit(){
    return (country == "CA" || country == "US" || country == "JP") ? "hours" : "days";
}
 

function clearErrorsMessages(){
    $('.validation-error').remove();
}

function pto_FormatDate( format, date ){

   var date =  moment(date).toDate();
   return moment(date).format('YYYY-MM-DD').toString();
   
}


function showModal(options){
      
      //TODO Replace it with proper RegEx
       var stripFND = function (str){
      
          if(str===null){
            return str;
          }

          var start = str.search("FND_MESSAGE") - 1;
          
          if(start<0){
            return str;
          }
          
          var end = null;

          for(var i=start;i<str.length;i++){
            if(str.charAt(i) === ')'){
               end = i+1;
               break;          
            }
          }

          return str.slice(0,start).trim()+" "+str.slice(end,str.length).trim();

        };
       
       if(options.type === 'error'){
       
        $('#statusModalMessage').html(stripFND(options.message));
       
       }else{
        
        $('#statusModalMessage').html("Your PTO request has been submitted successfully.");
        $('#statusModalDismiss').hide();
        $('#statusModalDismissSuccess').removeClass('hidden');

       }

       $('#statusModal').modal('show');
} 
window.onerror = function errorHandler(msg, url, line) {

    var name = "";
    if( !_.isNull(pto.getPTOResponse.employeePTO.body) ){
        name = " "+pto.getPTOResponse.employeePTO.body.employeeName;
    }
    var ERROR_MSG   = 'Sorry,'+ name +' something went wrong while processing your request. Please reach out to ' + '<a href="mailto:mypto-support@cisco.com">support</a>'+' for further assistance.';
    var noEmployeeExistsTemplate =  '<div class="container">\
                                        </br>\
                                        <div class="alert alert-info">\
                                          <div class="icon-align-middle"><i class="cisco-icon cisco-icon-info-12020-h27-w27"></i></div>\
                                          <div class="icon-align-middle">\
                                            <strong>'+ ERROR_MSG +'</strong>\
                                         </div>\
                                        </div>\
                                     </div>';

    $('#ea-app').html(noEmployeeExistsTemplate);
    return false;
};

window.addEventListener('error', function(e) { 
    ga('send', 'event', 'JavaScript Error', pto.getPTOResponse.employeePTO.body.employeeName , e.message, e.filename + ':  ' + e.lineno);  
}); 

$(document).ajaxError(function(e, request, settings) {
    ga('send', 'event', 'Ajax error', 'action', 'opt_label', e.result );
});

function removeHistoryDatesWithAllZero(){

    
   //remove 1.4 for peru and argentina
   if(country === "PE" || country === "AR"){
       
       ptoHistory.getPTOHistoryResponse.employeePTO.body.data = _.each(ptoHistory.getPTOHistoryResponse.employeePTO.body.data, function(item){ 
          
           var val = parseFloat(item['absenceHours']);
           item['absenceHours'] = val > 0 ? '1':'0';            
           return item;
           
       });
       
   }
   
   var datesToBeFreed   = [];
  
   var ptoHistoryByDates = _.groupBy( ptoHistory.getPTOHistoryResponse.employeePTO.body.data,'absenceDate');
   
   _.each( ptoHistoryByDates,function( ptoGroup,date ){
   
       var ptoHoursWithZero = _.where(ptoGroup,{'absenceHours':'0'});

        if(ptoHoursWithZero.length === ptoGroup.length ){
            datesToBeFreed.push(date);
        }
        
   });  

   ptoHistory.getPTOHistoryResponse.employeePTO.body.data = _.filter(ptoHistory.getPTOHistoryResponse.employeePTO.body.data,function(__ptoItem){
        return _.contains(datesToBeFreed,__ptoItem.absenceDate)? false : true;
   });
  
   if(hourType.getHourTypeResponse.employeePTO.body.data.length >= 2){
       if( hourType.getHourTypeResponse.employeePTO.body.data[1].type === "0100 Time2Give" ){
           hourType.getHourTypeResponse.employeePTO.body.data[1].code = "Time2Give";
           hourType.getHourTypeResponse.employeePTO.body.data[1].type = "Time2Give";
       }
   }
  
}